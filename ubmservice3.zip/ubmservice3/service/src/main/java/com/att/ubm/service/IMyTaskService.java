package com.att.ubm.service;

import com.att.ubm.model.MyTasksData;
import com.att.ubm.model.MyTasksModel;


public interface IMyTaskService {

	
	public MyTasksModel getTaskInfo(String id);	
	public MyTasksData myTaskDetails(String loggedUserId);
	public MyTasksData getAvailableList(String loggedUserId);	
	public MyTasksData getAssignedList(String loggedUserId) ;
}