package com.att.ubm.model;

import java.util.List;

public class GroupsDetailsModel {
	
	private String groupName;
	
	private List<EmployeeDetailsModel> keyValuePairsModel;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<EmployeeDetailsModel> getKeyValuePairsModel() {
		return keyValuePairsModel;
	}

	public void setKeyValuePairsModel(List<EmployeeDetailsModel> keyValuePairsModel) {
		this.keyValuePairsModel = keyValuePairsModel;
	}

	
	
	

	
	
	
	
	

}
