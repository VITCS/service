package com.att.ubm.model;

import java.io.Serializable;

public class CommonAttributes implements Serializable {
	
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
