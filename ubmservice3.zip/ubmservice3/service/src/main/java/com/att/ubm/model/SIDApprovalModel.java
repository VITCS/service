package com.att.ubm.model;

import java.io.Serializable;

public class SIDApprovalModel implements Serializable {
	
	private String sidId;
	private String activityName;
	private String activityAction;
	private String userId;
	private String startTS;
	private String endTS;
	public String getSidId() {
		return sidId;
	}
	public void setSidId(String sidId) {
		this.sidId = sidId;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getActivityAction() {
		return activityAction;
	}
	public void setActivityAction(String activityAction) {
		this.activityAction = activityAction;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStartTS() {
		return startTS;
	}
	public void setStartTS(String startTS) {
		this.startTS = startTS;
	}
	public String getEndTS() {
		return endTS;
	}
	public void setEndTS(String endTS) {
		this.endTS = endTS;
	}
	
	

}
