/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;

/**
 * @author kb942m
 *
 */


import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class CamundaBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String camundaServerUrl;
	private String adminUsername;
	private String adminPassword;
	public CamundaBean(){
		
	}
	
	public CamundaBean(String camundaServerUrl, String adminUsername, String adminPassword) {
		camundaServerUrl=camundaServerUrl;
		adminUsername=adminUsername;
		adminPassword=adminPassword;
	}
	public String getCamundaServerUrl() {
		return camundaServerUrl;
	}
	public void setCamundaServerUrl(String camundaServerUrl) {
		this.camundaServerUrl = camundaServerUrl;
	}
	public String getAdminUsername() {
		return adminUsername;
	}
	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	@Override
	public int hashCode() {
		 return HashCodeBuilder.reflectionHashCode(this);
	}
	@Override
	public boolean equals(Object obj) {
	  return EqualsBuilder.reflectionEquals(obj, this);
	} 
	
}
