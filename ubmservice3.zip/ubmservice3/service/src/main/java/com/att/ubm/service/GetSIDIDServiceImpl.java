package com.att.ubm.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.ubm.dao.IGetSIDIDDAO;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.att.ubm.model.BDContactsModel;
import com.att.ubm.model.CommonAttributes;
import com.att.ubm.model.HyperlinksModel;
import com.att.ubm.model.NarrativeModel;
import com.att.ubm.model.Plans;
import com.att.ubm.model.QUNarrativeModel;
import com.att.ubm.model.RequestorModel;
import com.att.ubm.model.SpecificAttributes;
import com.att.ubm.model.UIActionModel;
import com.att.ubm.util.DecoratorDate;
import com.att.aft.dme2.internal.gson.Gson;
import com.att.aft.dme2.internal.jettison.json.JSONArray;

/*import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;*/


@Service
public class GetSIDIDServiceImpl implements IGetSIDIDService {

	@Autowired
	IGetSIDIDDAO getSididDao;
	
	private String VALUE="value";
	
	@Override
	public String getNewSIDID() {
		System.out.println("Enter into GetSIDIDServiceImpl::getNewSIDID");
		String tempSidid=getSididDao.getNewSIDID();
		String arrayToJson=null;
		if(tempSidid!=null)
		{
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
			objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
			QUNarrativeModel model=new QUNarrativeModel();
			NarrativeModel narrative=new NarrativeModel();
			RequestorModel requestorModel=new RequestorModel();
			requestorModel.setRequestorEmailId("");
			requestorModel.setRequstorPhone("");
			narrative.setRequestor(requestorModel);
			BDContactsModel bdContactsModel=new BDContactsModel();
			bdContactsModel.setBdEmailId("");
			bdContactsModel.setBdPhone("");
			narrative.setBdContact(bdContactsModel);
			narrative.setRequestorName("");
			narrative.setRequestedDate("");
			narrative.setRequestedRDDate("");
			narrative.setSidRestriction("");
			narrative.setTelegenceImpacted("");
			narrative.setItProposedDate("");
			narrative.setTitanEnablerProposedImplementationDate("");
			narrative.setNarrativeProvidedBy("");
			narrative.setNarrativeTimeAndDateProvided("");
			narrative.setMarkets(null);
			narrative.setNarrativeText("");
			narrative.setTitanEnabledImpacted("");
			narrative.setProductApprovers(null);
			narrative.setRequiredCoreApproval(null);
			narrative.setMarketNarComments("");
			narrative.setFriendlyName("");
			narrative.setImpactWifi("");
			narrative.setMarketNarOverallReq("");
			model.setNarrative(narrative);
			model.setSidId(tempSidid);
			model.setSidDescription("");
			model.setSidType("");
			model.setSidReqType("");
			model.setVersion(1);
			model.setCreator("");
			String sidDate = DecoratorDate.dateToStringInFormat(new java.util.Date(), "MM/dd/yyyy", null);
			model.setVersionDate(sidDate);
			model.setActivity("Start");
			CommonAttributes comAttr=new CommonAttributes();
			comAttr.setDescription("");
			SpecificAttributes specificAttributes=new SpecificAttributes();
			specificAttributes.setApplicationChannel("");
			Plans plans=new Plans();
			plans.setCommonAttr(comAttr);
			plans.setSpecificAttr(specificAttributes);
			List<Plans> listofPlans=new ArrayList<>();
			listofPlans.add(plans);
			listofPlans.add(plans);
			model.setPlans(listofPlans);
			model.setActionTaken("");
			model.setUserIdTakingAction("");
			model.setComments("");
			model.setReasonCode("");
			model.setTaskId("");
			//org.json.simple.JSONArray ja=null;
				try {
					arrayToJson = objectMapper.writeValueAsString(model);
					System.out.println(arrayToJson);
					return arrayToJson;
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				System.out.println(arrayToJson);
				/*ja=new org.json.simple.JSONArray();
				ja.add(model);
					return ja;*/
				
				
		}
		return null;
		
	}
	
	@Override
	public String getHyperlinks() {
		String arrayToJson=null;
		try {
			List<HyperlinksModel> list=getSididDao.getHyperlinksDetails();
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
			objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
			if(list!=null)
			{
				arrayToJson = objectMapper.writeValueAsString(list);
			}
			System.out.println("whole String:\t"+arrayToJson);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arrayToJson;
	}
	
	@Override
	public Map<String,UIActionModel> getActionButtonDetails(String sidType, String pageName,String activityName) {
		String arrayToJson=null;
		try {
			List<UIActionModel> list=getSididDao.getActionButtonDetails(sidType, pageName,activityName);
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
			objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
			 //JSONObject responseDetailsJson = new JSONObject();
				/*responseDetailsJson.put("sidType", sidType);
				responseDetailsJson.put("activityName", activityName);
				responseDetailsJson.put("pageName", pageName);*/
			 //List<Object> newList=null;
			 Map<String,UIActionModel> tempMap=new LinkedHashMap<String,UIActionModel>();
			if(list!=null && list.size()>0)
			{
				//JSONObject tempResponseDetailsJson = new JSONObject();
				UIActionModel tempActionModel=null;
				for(UIActionModel model:list)
				{
					//newList=new ArrayList<Object>();
					tempActionModel=new UIActionModel();
					tempActionModel.setActionEnabled(model.isActionEnabled());
					tempActionModel.setActionVisibility(model.isActionVisibility());
					//arrayToJson = objectMapper.writeValueAsString(tempActionModel);
					//newList.add(arrayToJson);
					//tempResponseDetailsJson.put(model.getActionName(),tempActionModel);
					tempMap.put(model.getActionName(), tempActionModel);
					
				}
				//responseDetailsJson.put("ubmActions", tempResponseDetailsJson);
			}
			//System.out.println("whole String:\t"+arrayToJson);
			//System.out.println("tempResponseDetailsJson:\t"+tempResponseDetailsJson);
	    	//String tempStr=null;
			//tempStr = new Gson().toJson(responseDetailsJson);
			//System.out.println("tempStr:\t"+responseDetailsJson);
				
	    	return tempMap;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public Map<String,Object> valueMapper(Object value)
	{
		Map<String,Object> map=new HashMap<String,Object>();
		map.put(VALUE, value);
		return map;
	}
}
