package com.att.ubm.service;

import java.util.Map;

import com.att.ubm.model.UIActionModel;

public interface IGetSIDIDService {
	
	public String getNewSIDID();
	public String getHyperlinks();
	public Map<String,UIActionModel> getActionButtonDetails(String sidType,String pageName,String activityName);

}
