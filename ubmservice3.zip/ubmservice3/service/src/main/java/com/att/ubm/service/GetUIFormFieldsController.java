package com.att.ubm.service;



<<<<<<< HEAD
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class GetUIFormFieldsController implements IGetUIFormFileldsController {
	
	@Autowired
	IUIFormFieldService formFieldService;
	
	public GetUIFormFieldsController()
	{
		
	}
	
	@Override
	public String getFieldUINames(String sidType, String pageName,String activityName) {
=======
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ubm.model.UIFormFieldsModel;



@Component
public class GetUIFormFieldsController implements IGetUIFormFileldsController {
	
	@Autowired
	IUIFormFieldService formFieldService;
	
	public GetUIFormFieldsController()
	{
		
	}
	
	@Override
	public Map<String,UIFormFieldsModel> getFieldUINames(String sidType, String pageName,String activityName) {
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
		return formFieldService.getUIFormFieldsDetalls(sidType, pageName, activityName, null);
	}




	
	
	
}
