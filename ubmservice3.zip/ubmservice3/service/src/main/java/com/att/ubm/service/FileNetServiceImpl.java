package com.att.ubm.service;


import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.filenet.util.FileNetManager;
import com.att.ubm.dao.IFileNetDAO;
import com.att.ubm.model.FileNetConfigModel;


@Service
public class FileNetServiceImpl implements IFileNetService {

	@Autowired
	IFileNetDAO fileNetDAO;
	private FileNetConfigModel configModel=null;
	
	private static Logger log = LoggerFactory.getLogger(FileNetServiceImpl.class);
		
	@PostConstruct
	public void initIt() throws Exception {
		log.info("Init method after properties are set in FileNetServiceImpl ");
		configModel=fileNetDAO.getFileNetConfiguration();
	}

	

	@Override
	public String getFileNetInfo(String appName, String sidId, String subFolderName) {
		log.info("FileNetServiceImpl::getFileNetInfo::Application Name:\t"+appName);
		log.info("FileNetServiceImpl::getFileNetInfo::sidId:\t"+sidId);
		log.info("FileNetServiceImpl::getFileNetInfo::subFolderName:\t"+subFolderName);
		/*FileNetConfigModel configModel=new FileNetConfigModel();
		configModel.setMechId("m93911");
		configModel.setPassword("ETM3rdQtr#2018");
		configModel.setObjectStore("MIGRATION");
		configModel.setWebServiceURL("http://p8ecmcesd.web.att.com/wsi/FNCEWS40MTOM");
		configModel.setPathFolder("/Savvion/UEA SID/");
		configModel.setWebURL("https://p8ecmd.web.att.com/navigator/bookmark.jsp?desktop=MIGRATION&repositoryId=MIGRATION&repositoryType=p8&docid=replaceFolderId");*/
		
		if(configModel!=null)
		{
		FileNetManager fileNetManager=new FileNetManager(configModel);
		boolean parentFolderExistsInDBFlag=false;
		String parentFolderObjId=fileNetDAO.checkFolderInDB(appName, sidId, sidId);
		
			
		try {
			if(parentFolderObjId==null)
			{
				parentFolderExistsInDBFlag=true;
				String objectId=fileNetManager.createFolder(appName, sidId, sidId, parentFolderExistsInDBFlag);
				fileNetDAO.insertIntoFolderInfo(sidId, sidId, objectId, "mobility");
			}
			
			String subFolderId = fileNetDAO.checkFolderInDB("mobility",sidId,subFolderName);
			System.out.println("Sub folder:\t"+subFolderId);
			if(subFolderId==null)
			{
				String subFolderObjectId=fileNetManager.createSubFolder("mobility",sidId,subFolderName);
				fileNetDAO.insertIntoFolderInfo(sidId, subFolderName, subFolderObjectId, "mobility");
				subFolderId = fileNetDAO.checkFolderInDB("mobility",sidId,subFolderName);
			}
			String responseURL= formatFilenetURL(configModel.getWebURL(),subFolderId);
			log.info("FileNetServiceImpl::getFileNetInfo::responseURL\t"+responseURL);
			return responseURL;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		return null;
	}

	@Override
	public int getFileCount(String appName,String sidId, String folderName) {
		log.info("FileNetServiceImpl::getFileCount::Application Name:\t"+appName);
		log.info("FileNetServiceImpl::getFileCount::sidId:\t"+sidId);
		log.info("FileNetServiceImpl::getFileCount::subFolderName:\t"+folderName);
		String objectId=fileNetDAO.checkFolderInDB(appName,sidId,folderName);
		int fileCount=0;
		if(objectId!=null)
			try {
				fileCount = new FileNetManager(configModel).getItemCountInFolder(objectId,sidId, folderName);
				log.info("FileNetServiceImpl::getFileNetInfo::FileCount\t"+fileCount);
			} catch (Exception e) {
				e.printStackTrace();
			}
		return fileCount;
	}
	
	private String formatFilenetURL(String dbURL,String subFolderId)
	{
		if(dbURL!=null && subFolderId!=null)
		{
			return dbURL.replace("replaceFolderId",subFolderId);
		}
		return null;
	}
	
	
}
