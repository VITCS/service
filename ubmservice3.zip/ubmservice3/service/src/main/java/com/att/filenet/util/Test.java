package com.att.filenet.util;

import java.util.Calendar;

public class Test {

	public static void main(String[] args) {
		System.out.println(Calendar.getInstance().get(Calendar.YEAR));
	}
}
