package com.att.ubm.service;

<<<<<<< HEAD


public interface IUIFormFieldService {

	public String getUIFormFieldsDetalls(String sidType,String pageName,String activityName,String sidId);
=======
import java.util.Map;

import com.att.ubm.model.UIFormFieldsModel;

public interface IUIFormFieldService {

	public Map<String,UIFormFieldsModel> getUIFormFieldsDetalls(String sidType,String pageName,String activityName,String sidId);
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
}