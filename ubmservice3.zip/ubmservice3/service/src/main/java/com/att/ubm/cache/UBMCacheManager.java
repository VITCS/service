/**
 * 
 */
package com.att.ubm.cache;

import java.util.LinkedHashMap;
import java.util.Map;

import org.infinispan.manager.EmbeddedCacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.att.ubm.dao.IQUNarraitiveDAO;
import com.att.ubm.model.ApprovalOption;

/**
 * @author kb942m
 *
 */
@Component
@DependsOn(value = { "quNarraitiveDAO" })
@Lazy
@EnableCaching
public class UBMCacheManager {

	private static final Logger logger = LoggerFactory.getLogger(UBMCacheManager.class);

	public UBMCacheManager() {

	}

	@Autowired
	IQUNarraitiveDAO quNarraitiveDAO;

	@Autowired
	private EmbeddedCacheManager cacheManager;

	@EventListener(value = ApplicationReadyEvent.class)
	public void loadCacheOnStartupEvent() {
		final String METHOD = "getApproverOptions";
		logger.info("Entry={}", METHOD);
		getApproverOptionsCache();
		logger.info("Exit={}", METHOD);

	}

	public void getApproverOptionsCache() {
		Map<String, ApprovalOption> approvalOptionDetails = new LinkedHashMap<String, ApprovalOption>();
		try {

			Map<String, ApprovalOption> approvalOptionFilterCache = cacheManager.getCache("approvalOption");
			approvalOptionDetails = quNarraitiveDAO.getApproverOptions();
			if(approvalOptionDetails != null && !approvalOptionDetails.isEmpty()){
				for (Map.Entry<String, ApprovalOption> entry : approvalOptionDetails.entrySet()) {
					approvalOptionFilterCache.put(entry.getKey(), entry.getValue());
				}
			}

			logger.info("approvalInfoCache{}", approvalOptionFilterCache.size());

		} catch (Exception e) {
			logger.error("Exception occured while loading approver into Cache={}", e.getMessage(), e);
		}
	}

	public ApprovalOption getApproverOptionsInfoFromCache(String sidType) {
		ApprovalOption approvalOption = new ApprovalOption();

		Map<String, ApprovalOption> approvalOptionInfo = cacheManager.getCache("approvalOption");

		if (approvalOptionInfo == null || !approvalOptionInfo.containsKey(sidType)) {
			logger.info("Loading the {} Either cache {} is null or {} is not found in cache.", sidType);
			this.getApproverOptionsCache();
		}

		if (approvalOptionInfo != null && approvalOptionInfo.containsKey(sidType)) {
			approvalOption = approvalOptionInfo.get(sidType);
			logger.info("approvalOption is list found for ={}", approvalOptionInfo.size());
			
		} else {
			logger.info("approvalOption is not found for ={}", sidType);
		}

		return approvalOption;
	}

}
