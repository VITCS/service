package com.att.ubm.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("variables")
public class CamundaActionModel {
	
	private Map<String,String> actionTaken;
	private Map<String,String> requestor;
	private Map<String,String> creator;
	private Map<String,String> sidId;
	private Map<String,String> sidDesc;
	private Map<String,String> sidType;
	private Map<String,String> requestType;
	public Map<String, String> getActionTaken() {
		return actionTaken;
	}
	public void setActionTaken(Map<String, String> actionTaken) {
		this.actionTaken = actionTaken;
	}
	public Map<String, String> getRequestor() {
		return requestor;
	}
	public void setRequestor(Map<String, String> requestor) {
		this.requestor = requestor;
	}
	public Map<String, String> getCreator() {
		return creator;
	}
	public void setCreator(Map<String, String> creator) {
		this.creator = creator;
	}
	public Map<String, String> getSidId() {
		return sidId;
	}
	public void setSidId(Map<String, String> sidId) {
		this.sidId = sidId;
	}
	public Map<String, String> getSidDesc() {
		return sidDesc;
	}
	public void setSidDesc(Map<String, String> sidDesc) {
		this.sidDesc = sidDesc;
	}
	public Map<String, String> getSidType() {
		return sidType;
	}
	public void setSidType(Map<String, String> sidType) {
		this.sidType = sidType;
	}
	public Map<String, String> getRequestType() {
		return requestType;
	}
	public void setRequestType(Map<String, String> requestType) {
		this.requestType = requestType;
	}
	
	

}
