package com.att.ubm.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IGetUIFormFieldsDAO;
import com.att.ubm.model.UIFormFieldsModel;
import com.att.ubm.util.LabelCacheUtil;


@Repository
public class GetUIFormFieldsDAOImpl implements IGetUIFormFieldsDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	

	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}
	
	@Autowired
	@Qualifier("camundaJdbcTemplate")
	private JdbcTemplate ubmJdbcTemplate;
	
	


	public JdbcTemplate getUbmJdbcTemplate() {
		return ubmJdbcTemplate;
	}


	public void setUbmJdbcTemplate(JdbcTemplate ubmJdbcTemplate) {
		this.ubmJdbcTemplate = ubmJdbcTemplate;
	}



	
	@Override
	public List<UIFormFieldsModel> getUIFormFieldsDetalls(String activityName) {
<<<<<<< HEAD
		String sql = "select A.UBM_KEY as UBM_KEY,A.SCREEN_NAME as screeName, A.UBM_KEY_DESCRIPTION as fieldName, A.TOOL_TIP as toolTip, B.IS_ENABLED as isEnabled,B.FIELD_VISIBILITY,B.FIELD_REGEX,b.START_DISPLAY,b.END_DISPLAY  From ubm_tool_tip A JOIN sid_fields_info B on A.UBM_KEY=B.UBM_KEY " + 
				"JOIN sid_fields_map C on b.SID_FIELDS_MAPID=c.SID_FIELDS_MAPID JOIN UBM_ACTIVTY_INFO D on D.activity_id = C. activity_id WHERE  D.activity_name = ?";
=======
		/*String sql = "select A.UBM_KEY as UBM_KEY,A.SCREEN_NAME as screeName, A.UBM_KEY_DESCRIPTION as fieldName, A.TOOL_TIP as toolTip, B.IS_ENABLED as isEnabled,B.FIELD_VISIBILITY,B.FIELD_REGEX,b.START_DISPLAY,b.END_DISPLAY  From ubm_tooltip A JOIN sid_fields_info B on A.UBM_KEY=B.UBM_KEY " + 
				"JOIN sid_fields_map C on b.SID_FIELDS_MAPID=c.SID_FIELDS_MAPID JOIN UBM_ACTIVTY_INFO D on D.activity_id = C. activity_id WHERE  D.activity_desc = ? order by b.UBM_KEY";*/
		String sql="select A.UBM_KEY as UBM_KEY,PAGES.SID_PAGE_NAME as screeName, A.UBM_KEY_DESCRIPTION as fieldName, A.TOOL_TIP as toolTip, B.IS_ENABLED as isEnabled,B.FIELD_VISIBILITY,B.FIELD_REGEX,b.START_DISPLAY,b.END_DISPLAY  From ubm_tooltip A JOIN sid_fields_info B on A.UBM_KEY=B.UBM_KEY "+  
                " JOIN sid_fields_map C on b.SID_FIELDS_MAPID=c.SID_FIELDS_MAPID JOIN UBM_ACTIVTY_INFO D on D.activity_id = C. activity_id join ubm_sid_pages pages on PAGES.SID_PAGE_ID=A.SCREEN_ID WHERE  D.activity_desc = ? order by b.UBM_KEY";
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
		List<UIFormFieldsModel> uiFieldsModels=new ArrayList<UIFormFieldsModel>();
		try {
			System.out.println("Enter into getConfigKCPNVPDetalls");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql, activityName);
			
			UIFormFieldsModel model=null;
			while (sqlRowSet.next()) {
				model=new UIFormFieldsModel();
				model.setUbmKey(LabelCacheUtil.isNull(sqlRowSet.getString("UBM_KEY")));
				model.setScreenName(LabelCacheUtil.isNull(sqlRowSet.getString("screeName")));
				model.setUbmKeyDescription(LabelCacheUtil.isNull(sqlRowSet.getString("fieldName")));
				model.setToolTip(LabelCacheUtil.isNull(sqlRowSet.getString("toolTip")));
				model.setisEnabled(sqlRowSet.getBoolean("isEnabled"));
				model.setFieldVisibility(sqlRowSet.getBoolean("FIELD_VISIBILITY"));
				model.setFieldRegex(LabelCacheUtil.isNull(sqlRowSet.getString("FIELD_REGEX")));
				model.setStartDate(sqlRowSet.getLong("START_DISPLAY"));
				model.setEndDate(sqlRowSet.getLong("END_DISPLAY"));
				uiFieldsModels.add(model);
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return uiFieldsModels;
	}
	

}
