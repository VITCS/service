package com.att.ubm.model;

import java.io.Serializable;

public class Plans implements Serializable {
	
	private CommonAttributes commonAttr;
	private SpecificAttributes specificAttr;
	public CommonAttributes getCommonAttr() {
		return commonAttr;
	}
	public void setCommonAttr(CommonAttributes commonAttr) {
		this.commonAttr = commonAttr;
	}
	public SpecificAttributes getSpecificAttr() {
		return specificAttr;
	}
	public void setSpecificAttr(SpecificAttributes specificAttr) {
		this.specificAttr = specificAttr;
	}
	
	

}
