package com.att.ubm.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class UIFormFieldsModel implements Serializable {
	
	
	@JsonIgnore
	private String ubmKey;
	@JsonIgnore
	private String screenName;
<<<<<<< HEAD
	@JsonIgnore
=======
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
	private String ubmKeyDescription;
	private String toolTip;
	
	private boolean isEnabled;
	private boolean fieldVisibility;
	private String  fieldRegex;
	@JsonIgnore
	private long startDate;
	@JsonIgnore
	private long endDate;
	public String getUbmKey() {
		return ubmKey;
	}
	public void setUbmKey(String ubmKey) {
		this.ubmKey = ubmKey;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getUbmKeyDescription() {
		return ubmKeyDescription;
	}
	public void setUbmKeyDescription(String ubmKeyDescription) {
		this.ubmKeyDescription = ubmKeyDescription;
	}
	public String getToolTip() {
		return toolTip;
	}
	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}
	@com.fasterxml.jackson.annotation.JsonProperty(value="isEnabled")  
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setisEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public boolean isFieldVisibility() {
		return fieldVisibility;
	}
	public void setFieldVisibility(boolean fieldVisibility) {
		this.fieldVisibility = fieldVisibility;
	}
	public String getFieldRegex() {
		return fieldRegex;
	}
	public void setFieldRegex(String fieldRegex) {
		this.fieldRegex = fieldRegex;
	}
	public long getStartDate() {
		return startDate;
	}
	public void setStartDate(long startDate) {
		this.startDate = startDate;
	}
	public long getEndDate() {
		return endDate;
	}
	public void setEndDate(long endDate) {
		this.endDate = endDate;
	}
	
	

}
