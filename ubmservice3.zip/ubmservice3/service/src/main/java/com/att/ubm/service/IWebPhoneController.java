package com.att.ubm.service;


import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.GroupsDetailsModel;
import com.att.ubm.model.RequestorModel;

@Api
@Path("/service")
@Produces({ MediaType.APPLICATION_JSON })
public interface IWebPhoneController {

	@GET
	@Path("/requestor")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Requestor <attuid>!",
			notes = "Returns a JSON object of Requestor Info. "
					,
			response = RequestorModel.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public RequestorModel getRequestorDetails(@QueryParam("attuid") String attuid);
	
	@GET
	@Path("/getAllGroupMembers")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Requestor <attuid>!",
			notes = "Returns a JSON object of Requestor Info. "
					,
			response = GroupsDetailsModel.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public List<EmployeeDetailsModel> getAllGroupMembers(@QueryParam("groupName") String groupName);
	
	@GET
	@Path("/getMouseOverText")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Requestor <ScreeName!>",
			notes = "Returns a Map object of Tooltip Info. "
					,
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public Map<String,String> getMouseOver(@QueryParam("screenName") String screenName);
	
	@GET
	@Path("/getConfigDetails")
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Respond Configuration Details ",
			notes = "Returns a Configuration Info. "
					,
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Runtime error")
					})
	public String getConfigDetails(@QueryParam("sidType") String sidType,@QueryParam("pageName") String pageName,@QueryParam("sidId") String sidId);
}