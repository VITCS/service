/**
 * 
 */
package com.att.ubm.dao.impl;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IQUNarraitiveDAO;
import com.att.ubm.model.AlternateName;
import com.att.ubm.model.ApprovalName;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.BDContactsModel;
import com.att.ubm.model.ChannelName;
import com.att.ubm.model.ConfigKCPNVPModel;
import com.att.ubm.model.NarrativeModel;
import com.att.ubm.model.ProductName;
import com.att.ubm.model.QUNarrativeModel;
import com.att.ubm.model.QuickUpdate;
import com.att.ubm.model.RequestorModel;
import com.att.ubm.model.Voice;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.LabelCacheUtil;
import com.att.ubm.util.QUNarrativeConstants;
import java.sql.ResultSet;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

/**
 * @author kb942m
 *
 */
@Repository(value = "quNarraitiveDAO")
public class QUNarraitiveDAOImpl implements IQUNarraitiveDAO {

	private static final Logger logger = LoggerFactory.getLogger(QUNarraitiveDAOImpl.class);

	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}
	
	@Autowired
	@Qualifier("namedParameterJdbcTemplate")
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return namedParameterJdbcTemplate;
	}

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	@Autowired
	@Qualifier("camundaJdbcTemplate")
	private JdbcTemplate ubmJdbcTemplate;

	public JdbcTemplate getUbmJdbcTemplate() {
		return ubmJdbcTemplate;
	}

	public void setUbmJdbcTemplate(JdbcTemplate ubmJdbcTemplate) {
		this.ubmJdbcTemplate = ubmJdbcTemplate;
	}
	

	@Override
	public Map<String, ApprovalOption> getApproverOptions() {

		/*String APPROVAL_OPTIONS = "select page.sid_type as sidType,usr.id_ as userName ,kcp.key as keyName, usr.first_ as firstname,usr.last_ as lastname , "
				+ "  nvp.start_display ,nvp.end_display from ubm.config_nvp nvp ,ubm.config_kcp kcp,ubm.config_page page,camunda.ACT_ID_USER usr "
				+ " where PAGE.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and NVP.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and nvp.NAME = usr.id_ "
				+ " and page.PAGE_NAME='APPROVER'";*/
		String APPROVAL_OPTIONS="select stypes.sid_type_name as sidType,usr.id_ as userName ,kcp.key as keyName, usr.first_ as firstname,usr.last_ as lastname , " + 
				" nvp.start_display ,nvp.end_display from ubm.config_nvp nvp ,ubm.config_kcp kcp,ubm.config_page page,camunda.ACT_ID_USER usr, ubm_sid_pages spages,ubm_sid_types stypes " + 
				" where PAGE.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and NVP.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and nvp.NAME = usr.id_ and SPAGES.SID_PAGE_ID=PAGE.PAGE_ID and STYPES.SID_TYPE_ID=PAGE.SID_TYPE_ID " + 
				" and SPAGES.SID_PAGE_NAME='Approver' ";
		Map<String, List<ApprovalName>> approvalOptionDetails = new LinkedHashMap<String, List<ApprovalName>>();
		Map<String, ApprovalOption> approvalDetailsInfo = new LinkedHashMap<String, ApprovalOption>();
		String keyVal = "";
		try {
			SqlRowSet rs = jdbcTemplate.queryForRowSet(APPROVAL_OPTIONS);

			while (rs.next()) {
				keyVal = rs.getString("sidType");
				if (approvalOptionDetails.containsKey(keyVal)) {

					List<ApprovalName> approvalNameTempList = approvalOptionDetails.get(keyVal);
					ApprovalName approvalName = new ApprovalName();
					approvalName.setAttId(rs.getString("username"));
					approvalName.setName(rs.getString("keyName"));
					approvalName.setFirstName(rs.getString("firstname"));
					approvalName.setLastName(rs.getString("lastname"));
					approvalName.setStartDisplay(rs.getLong("START_DISPLAY"));
					approvalName.setEndDisplay(rs.getLong("END_DISPLAY"));
					approvalNameTempList.add(approvalName);
					approvalOptionDetails.put(keyVal, approvalNameTempList);
				} else {

					List<ApprovalName> approvalNameTempList = new ArrayList<ApprovalName>();
					ApprovalName approvalName = new ApprovalName();
					approvalName.setAttId(rs.getString("username"));
					approvalName.setName(rs.getString("keyName"));
					approvalName.setFirstName(rs.getString("firstname"));
					approvalName.setLastName(rs.getString("lastname"));
					approvalName.setStartDisplay(rs.getLong("START_DISPLAY"));
					approvalName.setEndDisplay(rs.getLong("END_DISPLAY"));
					approvalNameTempList.add(approvalName);
					approvalOptionDetails.put(keyVal, approvalNameTempList);

				}

			}

		} catch (DataAccessException e) {
			logger.error("Exception={}", e.getMessage(), e);
		}
		approvalDetailsInfo = this.getApprovalMapDetails(approvalOptionDetails);

		return approvalDetailsInfo;
	}

	public Map<String, ApprovalOption> getApprovalMapDetails(Map<String, List<ApprovalName>> approvalOptionDetails) {
		Map<String, ApprovalOption> approvalDetailsInfo = new LinkedHashMap<String, ApprovalOption>();
		ApprovalOption approvalOption = new ApprovalOption();
		for (Map.Entry<String, List<ApprovalName>> entry : approvalOptionDetails.entrySet()) {
			approvalOption = this.getApproverOptionsInfo(entry.getValue(), entry.getKey());
			approvalDetailsInfo.put(entry.getKey(), approvalOption);
		}
		return approvalDetailsInfo;
	}

	public ApprovalOption getApproverOptionsInfo(List<ApprovalName> approvalNameMapList, String sidType) {
		ApprovalOption approvalOption = null;
		QuickUpdate quickUpdate = null;
		Voice voice = null;
		List<ProductName> productNameList = new ArrayList<ProductName>();
		List<ChannelName> channelNameList = new ArrayList<ChannelName>();
		List<AlternateName> alternateNameList = new ArrayList<AlternateName>();
		ProductName productName = null;
		ChannelName channelName = null;
		AlternateName alternateName = null;
		String apprName = "";
		try {
			approvalOption = new ApprovalOption();
			quickUpdate = new QuickUpdate();
			voice = new Voice();
			String name = "";
			if (approvalNameMapList != null && !approvalNameMapList.isEmpty()) {
				for (ApprovalName approvalNameModel : approvalNameMapList) {

					apprName = approvalNameModel.getName().substring(0, 7);
					if (approvalNameModel.getName() != null && !approvalNameModel.getName().isEmpty()) {
						name = approvalNameModel.getName().substring(8);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.PRODUCT)) {
						productName = new ProductName();
						productName.setFirstName(approvalNameModel.getFirstName());
						productName.setLastName(approvalNameModel.getLastName());
						productName.setUserName(approvalNameModel.getAttId());
						productName.setName(name);
						productNameList.add(productName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.CHANNEL)) {

						channelName = new ChannelName();
						channelName.setFirstName(approvalNameModel.getFirstName());
						channelName.setLastName(approvalNameModel.getLastName());
						channelName.setUserName(approvalNameModel.getAttId());
						channelName.setName(name);
						channelNameList.add(channelName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.ALTERNATE)) {
						name = approvalNameModel.getName().substring(10);
						alternateName = new AlternateName();
						alternateName.setFirstName(approvalNameModel.getFirstName());
						alternateName.setLastName(approvalNameModel.getLastName());
						alternateName.setUserName(approvalNameModel.getAttId());
						alternateName.setName(name);
						alternateNameList.add(alternateName);
					}

					if (sidType.equalsIgnoreCase(QUNarrativeConstants.QUICKUPDATE)) {
						quickUpdate.setProduct(productNameList);
						quickUpdate.setChannel(channelNameList);
						quickUpdate.setAlternate(alternateNameList);
						approvalOption.setQuickUpdate(quickUpdate);
					} else if (sidType.equalsIgnoreCase(QUNarrativeConstants.VOICE)) {
						voice.setProduct(productNameList);
						voice.setChannel(channelNameList);
						voice.setAlternate(alternateNameList);
						approvalOption.setVoice(voice);
					}

				}

			}

		} catch (Exception e) {
			logger.error("Exception={}", e.getMessage(), e);
		}

		return approvalOption;
	}

	@Override
	public int insertNarrativeForm(String tabName,QUNarrativeModel quNarrativeModel) {

		/*final String INSERT_SQL = "INSERT INTO"+ tabName+" (SID_ID,SID_TYPE,REQ_TYPE,VERSION,VERSION_TS,SID_DESC,CREATOR_ID,REQUESTOR_ID,REQUESTOR_PHONE,REQUESTOR_EMAIL,BUS_DEV_DISP_NM,BUS_DEV_PHONE,"
				+ "BUS_DEV_EMAIL,REQUESTED_DATE,SID_RESTRICTION,IT_TLG_IMPACTED,IT_TLG_IMPL_DATE,TE_IMPL_DATE,IT_TLG_NARR_USER_ID,IT_TLG_NARR_TS,IT_TLG_NARRATIVE,TITAN_ENABLER_IMPACTED,USER_ID,AUDIT_TS)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,systimestamp)";*/
		
		SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName(tabName);
		
		try {
			java.util.Date dateSidVersion = new java.util.Date();
			DecoratorDate.stringToDateInFormat(quNarrativeModel.getVersionDate(), dateSidVersion, "MM-dd-yyyy", null);
			Timestamp timeStampSidVersion = DecoratorDate.dateToSQLTimestamp(dateSidVersion);
			 Map<String, Object> parameters = new HashMap<String, Object>();
			    parameters.put("SID_ID", quNarrativeModel.getSidId());
			    parameters.put("SID_TYPE", quNarrativeModel.getSidType());
			    parameters.put("REQ_TYPE", quNarrativeModel.getSidReqType());
			    parameters.put("VERSION", quNarrativeModel.getVersion());
			    parameters.put("VERSION_TS", timeStampSidVersion);
			    parameters.put("SID_DESC", quNarrativeModel.getSidDescription());
			    parameters.put("CREATOR_ID", quNarrativeModel.getCreator());
			    parameters.put("REQUESTOR_ID", quNarrativeModel.getNarrative().getRequestorName());
			    parameters.put("REQUESTOR_PHONE", quNarrativeModel.getNarrative().getRequestor().getRequstorPhone());
			    parameters.put("REQUESTOR_EMAIL", quNarrativeModel.getNarrative().getRequestor().getRequestorEmailId());
			    parameters.put("BUS_DEV_DISP_NM", quNarrativeModel.getNarrative().getBdContactName());
			    parameters.put("BUS_DEV_PHONE", quNarrativeModel.getNarrative().getBdContact().getBdPhone());
			    parameters.put("BUS_DEV_EMAIL", quNarrativeModel.getNarrative().getBdContact().getBdEmailId());
			    System.out.println("quNarrativeModel.getNarrative().getRequestedDate():\t"+quNarrativeModel.getNarrative().getRequestedDate());
			    Timestamp tempImplDate=null;
			    if(quNarrativeModel.getNarrative().getRequestedDate()!=null)
			    {
			   
			    tempImplDate = DecoratorDate.stringToUBMImplDate(quNarrativeModel.getNarrative().getRequestedDate());
			    System.out.println("tempImplDate:\t"+tempImplDate.toString());
			    parameters.put("REQ_IMPL_DATE", tempImplDate);
			    }
			    else
			    {
			    	parameters.put("REQ_IMPL_DATE", null);
			    }
			    parameters.put("SID_RESTRICTION", quNarrativeModel.getNarrative().getSidRestriction());
			    parameters.put("IT_TLG_IMPACTED", quNarrativeModel.getNarrative().getTelegenceImpacted());
				tempImplDate = DecoratorDate.stringToUBMImplDate(quNarrativeModel.getNarrative().getItProposedDate()); //IT Proposed Implementation Date:
			    parameters.put("IT_TLG_IMPL_DATE", tempImplDate);
			    tempImplDate = DecoratorDate.stringToUBMImplDate(quNarrativeModel.getNarrative().getTitanEnablerProposedImplementationDate()); //Titan Enabler Proposed Implementation Date
			    parameters.put("TE_IMPL_DATE", tempImplDate);
			    parameters.put("IT_TLG_NARR_USER_ID", quNarrativeModel.getNarrative().getNarrativeProvidedBy());
			    tempImplDate = DecoratorDate.stringToUBMImplDateInFormat(quNarrativeModel.getNarrative().getNarrativeTimeAndDateProvided(), "MM/dd/yyyy hh:mm:ss a");
			    parameters.put("IT_TLG_NARR_TS", tempImplDate);
			    parameters.put("IT_TLG_NARRATIVE", quNarrativeModel.getNarrative().getNarrativeText());
			    parameters.put("TITAN_ENABLER_IMPACTED", quNarrativeModel.getNarrative().getTitanEnabledImpacted());
			    //parameters.put("USER_ID", quNarrativeModel.getUserIdTakingAction());
			    parameters.put("MARKET_NARRATIVE_COMMENTS", quNarrativeModel.getNarrative().getMarketNarComments());
			    parameters.put("FRIENDLY_NAME", quNarrativeModel.getNarrative().getFriendlyName());
			    parameters.put("IMPACT_WIFI", quNarrativeModel.getNarrative().getImpactWifi());
			    parameters.put("MARKET_NAR_OVERALLREQ", quNarrativeModel.getNarrative().getMarketNarOverallReq());
<<<<<<< HEAD
			    if(quNarrativeModel.getNarrative().getBdContactName()!=null && quNarrativeModel.getNarrative().getBdContactName().contains(":"))
			    	parameters.put("FINANCE_APPROVER_ID", quNarrativeModel.getNarrative().getBdContactName().split(":")[1]);
			    else
			    	parameters.put("FINANCE_APPROVER_ID","");
=======
			    parameters.put("ACTIVITY", quNarrativeModel.getActivity());
			    
			    if(quNarrativeModel.getNarrative().getBdContactName()!=null && quNarrativeModel.getNarrative().getBdContactName().contains(":"))
			    	parameters.put("FINANCE_APPROVER_ID", quNarrativeModel.getNarrative().getBdContactName().split(":")[1]);
			    else
			    	parameters.put("FINANCE_APPROVER_ID","");
			    parameters.put("REASON_CODE", quNarrativeModel.getReasonCode());
			    if(quNarrativeModel.getNarrative().getRequestedRDDate()!=null)
			    {
			   
			    tempImplDate = DecoratorDate.stringToUBMImplDate(quNarrativeModel.getNarrative().getRequestedRDDate());
			    parameters.put("REQUESTED_RD_DATE", tempImplDate);
			    }
			    else
			    {
			    	parameters.put("REQUESTED_RD_DATE", null);
			    }
			    parameters.put("COMMENTS", quNarrativeModel.getComments());
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
			   // parameters.put("AUDIT_TS", "systimestamp");
			    int retVal= simpleJdbcInsert.execute(parameters);
			    System.out.println("Executed Successfully.."+retVal);
			    return retVal;
		} catch (DataAccessException e) {
			e.printStackTrace();
			logger.error("Exception={}", e.getMessage(), e);
		}
		return 0;

	}

	@Override
	public int deleteMultiSelectRow(String tName,String sidId) {
		try {
			String deleteQuery = "delete from "+tName +" where sid_id=?";

			
			try {
				return jdbcTemplate.update(deleteQuery, new Object[]{sidId});

			} catch (DataAccessException e) {
				logger.error("Exception={}", e.getMessage(), e);
			}

		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}

	@Override
	public QUNarrativeModel getNarrativeFormValues(String sidId) {
		String selectQuery = "select SID_ID,SID_TYPE,REQ_TYPE,VERSION,VERSION_TS,SID_DESC,CREATOR_ID,REQUESTOR_ID,REQUESTOR_PHONE,REQUESTOR_EMAIL,BUS_DEV_DISP_NM,BUS_DEV_PHONE," + 
<<<<<<< HEAD
				"BUS_DEV_EMAIL,REQ_IMPL_DATE,SID_RESTRICTION,IT_TLG_IMPACTED,IT_TLG_IMPL_DATE,TE_IMPL_DATE,IT_TLG_NARR_USER_ID,IT_TLG_NARR_TS,IT_TLG_NARRATIVE,TITAN_ENABLER_IMPACTED,MARKET_NARRATIVE_COMMENTS,FRIENDLY_NAME,IMPACT_WIFI,MARKET_NAR_OVERALLREQ,FINANCE_APPROVER_ID from sid_narr where sid_id=?";
=======
				"BUS_DEV_EMAIL,REQ_IMPL_DATE,SID_RESTRICTION,IT_TLG_IMPACTED,IT_TLG_IMPL_DATE,TE_IMPL_DATE,IT_TLG_NARR_USER_ID,IT_TLG_NARR_TS,IT_TLG_NARRATIVE,TITAN_ENABLER_IMPACTED,MARKET_NARRATIVE_COMMENTS,FRIENDLY_NAME,IMPACT_WIFI,MARKET_NAR_OVERALLREQ,FINANCE_APPROVER_ID,ACTIVITY,REASON_CODE,REQUESTED_RD_DATE,COMMENTS from sid_narr where sid_id=?";
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
		try {
			return jdbcTemplate.queryForObject(selectQuery, new Object[] {sidId}, new NarrativeRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	class NarrativeRowMapper implements RowMapper<QUNarrativeModel>{

		@Override
		public QUNarrativeModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			QUNarrativeModel narrativeModel = new QUNarrativeModel();
			narrativeModel.setSidId(LabelCacheUtil.isNull(rs.getString("SID_ID")));
			narrativeModel.setSidType(LabelCacheUtil.isNull(rs.getString("SID_TYPE")));
			narrativeModel.setSidReqType(LabelCacheUtil.isNull(rs.getString("REQ_TYPE")));
			narrativeModel.setActivity(LabelCacheUtil.isNull(rs.getString("ACTIVITY")));
			
			narrativeModel.setVersion(rs.getInt("VERSION"));
			java.sql.Date tempDate = rs.getDate("VERSION_TS");
			
			String sSidVersionDate = (!rs.wasNull()) ? DecoratorDate
					.dateToStringInFormat(tempDate, "MM/dd/yyyy", null) : "";
				narrativeModel.setVersionDate(sSidVersionDate);
			narrativeModel.setSidDescription(LabelCacheUtil.isNull(rs.getString("SID_DESC")));
			narrativeModel.setUserIdTakingAction(LabelCacheUtil.isNull(rs.getString("CREATOR_ID")));
			NarrativeModel tempNarrativeModel=new NarrativeModel();
			tempNarrativeModel.setRequestorName(LabelCacheUtil.isNull(rs.getString("REQUESTOR_ID")));
			RequestorModel requestorModel=new RequestorModel();
			requestorModel.setRequstorPhone(LabelCacheUtil.isNull(rs.getString("REQUESTOR_PHONE")));
			requestorModel.setRequestorEmailId(LabelCacheUtil.isNull(rs.getString("REQUESTOR_EMAIL")));
			tempNarrativeModel.setRequestor(requestorModel);
			tempNarrativeModel.setBdContactName(LabelCacheUtil.isNull(rs.getString("BUS_DEV_DISP_NM")));
			BDContactsModel bdContacts=new BDContactsModel();
			bdContacts.setBdPhone(LabelCacheUtil.isNull(rs.getString("BUS_DEV_PHONE")));
			bdContacts.setBdEmailId(LabelCacheUtil.isNull(rs.getString("BUS_DEV_EMAIL")));
			tempNarrativeModel.setBdContact(bdContacts);
			tempDate = rs.getDate("REQ_IMPL_DATE");
			String sRequestImplDate = (!rs.wasNull()) ? DecoratorDate
					.dateToStringInFormat(tempDate, "MM/dd/yyyy", null) : "";
			tempNarrativeModel.setRequestedDate(LabelCacheUtil.isNull(sRequestImplDate));
			tempDate = rs.getDate("REQUESTED_RD_DATE");
			String sRequestRDDate = (!rs.wasNull()) ? DecoratorDate
					.dateToStringInFormat(tempDate, "MM/dd/yyyy", null) : "";
			tempNarrativeModel.setRequestedRDDate(LabelCacheUtil.isNull(sRequestRDDate));
			tempNarrativeModel.setSidRestriction(LabelCacheUtil.isNull(rs.getString("SID_RESTRICTION")));
			tempNarrativeModel.setTelegenceImpacted(LabelCacheUtil.isNull(rs.getString("IT_TLG_IMPACTED")));
			tempDate = rs.getDate("IT_TLG_IMPL_DATE");
			String sTlgImplDate = (!rs.wasNull()) ? DecoratorDate
					.dateToStringInFormat(tempDate, "MM/dd/yyyy", null) : "";
			tempNarrativeModel.setItProposedDate(LabelCacheUtil.isNull(sTlgImplDate));
			tempDate = rs.getDate("TE_IMPL_DATE");
			String sTeImpl = (!rs.wasNull()) ? DecoratorDate
					.dateToStringInFormat(tempDate, "MM/dd/yyyy", null) : "";
			tempNarrativeModel.setTitanEnablerProposedImplementationDate(LabelCacheUtil.isNull(sTeImpl));
			tempNarrativeModel.setNarrativeProvidedBy(LabelCacheUtil.isNull(rs.getString("IT_TLG_NARR_USER_ID")));
			java.sql.Timestamp tempTimestamp = rs.getTimestamp("IT_TLG_NARR_TS");
			String dataNarTlgProvideTime = (!rs.wasNull()) ? DecoratorDate.dateToStringInFormat(tempTimestamp, "MM/dd/yyyy hh:mm:ss a", null) : "";
			tempNarrativeModel.setNarrativeTimeAndDateProvided(dataNarTlgProvideTime);
			tempNarrativeModel.setMarkets(getMultISelectValues(narrativeModel.getSidId(), "MARKETS"));
			tempNarrativeModel.setNarrativeText(LabelCacheUtil.isNull(rs.getString("IT_TLG_NARRATIVE")));
			tempNarrativeModel.setTitanEnabledImpacted(LabelCacheUtil.isNull(rs.getString("TITAN_ENABLER_IMPACTED")));
			tempNarrativeModel.setProductApprovers(getMultISelectValues(narrativeModel.getSidId(), "OPTIONAL APPROVER"));
			tempNarrativeModel.setRequiredCoreApproval(getMultISelectValues(narrativeModel.getSidId(), "REQUIRED APPROVER"));
			tempNarrativeModel.setMarketNarComments(LabelCacheUtil.isNull(rs.getString("MARKET_NARRATIVE_COMMENTS")));
			tempNarrativeModel.setFriendlyName(LabelCacheUtil.isNull(rs.getString("FRIENDLY_NAME")));
			tempNarrativeModel.setImpactWifi(LabelCacheUtil.isNull(rs.getString("IMPACT_WIFI")));
			tempNarrativeModel.setMarketNarOverallReq(LabelCacheUtil.isNull(rs.getString("MARKET_NAR_OVERALLREQ")));
			narrativeModel.setNarrative(tempNarrativeModel);
			narrativeModel.setReasonCode(LabelCacheUtil.isNull(rs.getString("REASON_CODE")));
			narrativeModel.setComments(LabelCacheUtil.isNull(rs.getString("COMMENTS")));
			return narrativeModel;
		}

		
	}

	@Override
	public int insertMultiSelects(String tabName,String sidId,String listName, List<String> values,String creator) {
		try {
			SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName(tabName);
			 Map<String, Object> parameters = new HashMap<String, Object>();
			 if(values!=null && values.size()>0)
			 {
			 List<Map<String, Object>> batchValues = new ArrayList<>(values.size());
			 for(String val:values)
			 {
				 parameters = new HashMap<String, Object>();
				 parameters.put("SID_ID", sidId);
				 parameters.put("LIST_NAME", listName);
				 parameters.put("DESCRIPTION", val);
				 parameters.put("DISP_NM", val);
				 parameters.put("USER_ID", creator);
				 batchValues.add(parameters);
			 }
			 int[] ints = simpleJdbcInsert.executeBatch(batchValues.toArray(new Map[values.size()]));
			 return ints.length;
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public boolean rowExists(String tName, String sidId) {
		SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet("select sid_id from "+tName+" where sid_id=?",sidId);
		if (sqlRowSet.next()) 
			return true;
		return false;
	}
	
	@Override
	public int updateNarrativeForm(String tableName, String query,Map<String, Object> paramValues) {
		SqlParameterSource namedParameters = new MapSqlParameterSource(paramValues);
		System.out.println(paramValues);
		
		 int retVal= namedParameterJdbcTemplate.update(query,namedParameters);
		return retVal;
	}

	@Override
	public Map<String, String> getJsonDBMapping(String sidType) {
		String sql = "SELECT JSON_COLUMN_NAME, DB_COLUMN_NAME FROM JSON_DB_MATRIX WHERE SID_TYPE = ?";
		Map<String, String> jsonDbMapping = new HashMap<String, String>();
		try {
			System.out.println("Enter into getJsonDBMapping");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,sidType);
			while (sqlRowSet.next()) {
			
				jsonDbMapping.put(sqlRowSet.getString("JSON_COLUMN_NAME"), LabelCacheUtil.getToolTipValue(sqlRowSet.getString("DB_COLUMN_NAME")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return jsonDbMapping;
	}

	@Override
	public Map<String, String> getMultiSelectJsonIgnoreColumns(String sidType) {
		String sql = "SELECT JSON_LIST_NAME, DB_LIST_NAME FROM JSON_DB_MATRIX WHERE SID_TYPE = ? and  JSON_LIST_NAME is not null and DB_LIST_NAME is not null";
		Map<String, String> jsonignoreMapping = new HashMap<String, String>();
		try {
			System.out.println("Enter into multiSelectJsonIgnoreColumns");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,sidType);
			while (sqlRowSet.next()) {
			
				jsonignoreMapping.put(sqlRowSet.getString("JSON_LIST_NAME"), LabelCacheUtil.getToolTipValue(sqlRowSet.getString("DB_LIST_NAME")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return jsonignoreMapping;
	}

	@Override
	public String getColumnValueFromSidNarr(String sidId, String columnName) {
		// TODO Auto-generated method stub
		String columnVal = null;
		String sql = "Select "  + columnName +" from sid_narr where sid_id = ?"; 
		try {
			System.out.println("Enter into getColumnValueFromSidNarr");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql, sidId);
			
			while (sqlRowSet.next()) {
				columnVal = sqlRowSet.getString(columnName);
				System.out.println("Vlaue of columnVal from sqlrowset " + columnVal);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return columnVal;
	}
	
<<<<<<< HEAD
	public List<String> getMultISelectValues(String sidId,String listName) {
		String sql = "select DISP_NM from sid_narr_list where sid_id=? and LIST_NAME=?";
		List<String> multiValues=new ArrayList<String>();
		try {
			System.out.println("Enter into getConfigKCPNVPDetalls");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,sidId,listName);
			
			while (sqlRowSet.next()) {
				multiValues.add(LabelCacheUtil.isNull(sqlRowSet.getString("DISP_NM")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return multiValues;
	}
=======
	@Override
	public List<String> getMultISelectValues(String sidId,String listName) {
		String sql = "select DISP_NM from sid_narr_list where sid_id=? and LIST_NAME=?";
		List<String> multiValues=new ArrayList<String>();
		try {
			System.out.println("Enter into getConfigKCPNVPDetalls");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,sidId,listName);
			
			while (sqlRowSet.next()) {
				multiValues.add(LabelCacheUtil.isNull(sqlRowSet.getString("DISP_NM")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return multiValues;
	}

	@Override
	public int saveUBMRequest(String tableName, String sidId,String activityName,String jsonString, String userId) throws Exception {
		SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName(tableName);
		
			 Map<String, Object> parameters = new HashMap<String, Object>();
			    parameters.put("SID_ID", sidId);
			    parameters.put("ACTIVITY_NAME", activityName);
			    parameters.put("INPUT_JSON", jsonString);
			    parameters.put("AUDIT_TS", new Timestamp(System.currentTimeMillis()));
			    parameters.put("USERID", userId);
			    int retVal= simpleJdbcInsert.execute(parameters);
			    System.out.println("Executed saveUBMRequest Successfully.."+retVal);
			    return retVal;

	}

	@Override
	public int saveUBMResponse(String tableName, String sidId,String activityName,String responseText,String errorDesc) throws Exception {
SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate).withTableName(tableName);
		
			 Map<String, Object> parameters = new HashMap<String, Object>();
			    parameters.put("SID_ID", sidId);
			    parameters.put("ACTIVITY_NAME", activityName);
			    parameters.put("RESPONSE", responseText);
			    parameters.put("AUDIT_TS", new Timestamp(System.currentTimeMillis()));
			    parameters.put("ERROR_DESC", errorDesc);
			    int retVal= simpleJdbcInsert.execute(parameters);
			    System.out.println("Executed saveUBMRequest Successfully.."+retVal);
			    return retVal;
	}
	
	@Override
	public Map<String, String> getErrorCodes() {
		String sql = "SELECT ERROR_CODE, ERROR_MESSAGE FROM UBM_ERRORS_CODES";
		Map<String, String> jsonDbMapping = new HashMap<String, String>();
		try {
			System.out.println("Enter into getJsonDBMapping");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql);
			while (sqlRowSet.next()) {
			
				jsonDbMapping.put(sqlRowSet.getString("ERROR_CODE"), LabelCacheUtil.getToolTipValue(sqlRowSet.getString("ERROR_MESSAGE")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return jsonDbMapping;
	}

	
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
	

}
