package com.att.ubm.util;



public class LabelCacheUtil 
{
	
	public static String isNull(String value) {
		if (null != value) {
			if (value.trim().length() == 0) {
				return "";
			}

			return value;
		} else
			return "";
	}
	
	public static final String stringReplace(String str, String sThis, String sThat)
	{
		int i;

		if (str == null) return null;

		i = 0;
		while ((i = str.indexOf( sThis, i )) != -1)
		{
			str = str.substring(0,i) + sThat + str.substring( i+sThis.length() );
			i += sThat.length( );
		}

		return str;
	}
	
	public static String getToolTipValue(String sValue)
	{
		try
		{
	                sValue = stringReplace(sValue, "<BR />", "|BR /|");
	                sValue = stringReplace(sValue, "<B>", "|B|");
	                sValue = stringReplace(sValue, "</B>", "|/B|");
	                sValue = stringReplace(sValue, "<U>", "|U|");
	                sValue = stringReplace(sValue, "</U>", "|/U|");
	                sValue = markup(sValue);
	                sValue = stringReplace(sValue, "|BR&nbsp;/|", "<BR />");
	                sValue = stringReplace(sValue, "|B|", "<B>");
	                sValue = stringReplace(sValue, "|/B|", "</B>");
	                sValue = stringReplace(sValue, "|U|", "<U>");
	                sValue = stringReplace(sValue, "|/U|", "</U>");

	                // Doing this for JavaScript toolbox pop up.
	                sValue = stringReplace(sValue, "'", "\\'");
			return sValue;

		} catch (Exception e)
		{
			return "";
		}
	}
	public static String markup(String text)
	{
	    if (!Validator.isValidString(text))
	    {
	        return "";
	    }

	    StringBuffer buffer = new StringBuffer();
	    for (int i = 0; i < text.length(); i++)
	    {
	        char c = text.charAt(i);
	        switch (c)
	        {
	            case '<':
	                buffer.append("&lt;");
	                break;
	            case '&':
	                buffer.append("&amp;");
	                break;
	            case '>':
	                buffer.append("&gt;");
	                break;
	            case '"':
	                buffer.append("&quot;");
	                break;
	            case ' ':
	                buffer.append("&nbsp;");
	                break;
	            default:
	                buffer.append(c);
	                break;
	        }
	    }
	    return buffer.toString();
	}


}