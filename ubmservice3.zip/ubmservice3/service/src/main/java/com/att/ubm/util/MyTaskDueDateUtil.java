/**
 * 
 */
package com.att.ubm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author kb942m
 *
 */
public class MyTaskDueDateUtil {
	private static final Logger logger = LoggerFactory.getLogger(MyTaskDueDateUtil.class);

	public static boolean convertDateFormate(String inputDueDate) {

		SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy HH:mm aaa");
		Date currentDate = new Date();
		boolean dueFlag = false;
		try {

			Date dueDate = formatter.parse(inputDueDate);
			String formattedDueDate = formatter.format(dueDate);
			String formattedCurrentDate = formatter.format(currentDate);
			if (formattedDueDate.compareTo(formattedCurrentDate) < 0) {
				dueFlag = true;
			} else {
				dueFlag = false;
			}

		} catch (ParseException e) {
			logger.error("Exception={}", e.getMessage(), e);
		}
		return dueFlag;

	}

}
