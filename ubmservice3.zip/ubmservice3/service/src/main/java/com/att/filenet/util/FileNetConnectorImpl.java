package com.att.filenet.util;


import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;

import javax.security.auth.Subject;

import org.slf4j.LoggerFactory;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.DocumentSet;
import com.filenet.api.collection.FolderSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.collection.ReferentialContainmentRelationshipSet;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.IndependentObject;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.filenet.apiimpl.core.DocumentImpl;


public class FileNetConnectorImpl implements IFileNetConnector {


	private final String ceURL;

	private Connection conn;
	private Domain domain;

	private Subject subject;
	private int docCount=0;
	private static Logger logger = LoggerFactory.getLogger(FileNetConnectorImpl.class);

	/**
	 * ConnectorImpl Contructor for Web-Based Logins
	 *
	 * Ie. Sample with WebSphere
	 * com.ibm.websphere.security.auth.WSSubject.getCallerSubject();
	 * http://www-01.ibm.com/support/knowledgecenter/SS7K4U_8.5.5/com.ibm.
	 * websphere.zseries.doc/ae/rsec_logmod.html
	 *
	 * @param ceURL
	 *            Content Engine Url
	 * @param subject
	 *            Authentication Subject
	 */
	public FileNetConnectorImpl(String ceURL, Subject subject) {
		this.ceURL = ceURL;
		this.subject = subject;
		// cleanExistContexts();
		UserContext uc = UserContext.get();
		uc.pushSubject(subject);
	}

	/**
	 * For Non Based Applications (Username login)
	 *
	 * @param ceURL
	 *            Content Engine URL
	 * @param username
	 *            UserName
	 * @param password
	 *            Password
	 * @param stanza
	 *            Stanza
	 */
	public FileNetConnectorImpl(String ceURL, String username, String password, String stanza) {
		this.ceURL = ceURL;
		logger.info("FileNetConnectorImpl()", "FileNetConnectorImpl");
		this.conn = Factory.Connection.getConnection(this.ceURL); // Initialize
		logger.info("FileNetConnectorImpl()", "After Connection");											// connection
																	// object

		cleanExistContexts(); // Clean up existing authentication subjects if
		logger.info("FileNetConnectorImpl()", "Clear User Context");											// connection				// any
		createSubject(username, password, "FileNetP8WSI");
		logger.info("FileNetConnectorImpl()", "After Create Subject");											// connection// Create an authentication
													// subject

	}

	
	public Folder createFolder(ObjectStore objectStore, String name, Folder parent) {
		Folder subFolder = parent.createSubFolder(name);
		subFolder.save(RefreshMode.REFRESH);
		/*AccessPermissionList ap = subFolder.get_Permissions();
		AccessPermission abc=(AccessPermission) Factory.AccessPermission.createInstance();
		int value=AccessRight.PUBLISH.getValue() | AccessRight.VIEW_CONTENT.getValue() | AccessRight.WRITE.getValue() ;
		abc.createInstance().set_AccessMask(value);
		ap.add(ap);
		subFolder.set_Permissions(ap);*/
		
		
		
				
		/*PropertyFilter pf;
		pf= new PropertyFilter();
		   pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.ID, null));*/

		/*IndependentObjectSet folderSet = (IndependentObjectSet) subFolder.get_Permissions();

		Iterator itr=folderSet.iterator();
		while (itr.hasNext())
		{
			IndependentObject independentObject = (IndependentObject) itr.next();
		}*/
		/*AccessPermissionList ap = (AccessPermissionList) Factory.AccessPermission.createList();
		   ap.add(AccessRight.READ_ACL);
		   subFolder.set_Permissions(ap);*/
		// separate Folder
						
		// set parent
		logger.info("Folder created");
		//System.out.println("Folder created");
		//System.out.println(subFolder.getProperties().get(PropertyNames.SUB_FOLDERS));
		//System.out.println(subFolder.getProperties().get(PropertyNames.FOLDER_NAME));
		
		
		//ClassDefinition cd = Factory.ClassDefinition.fetchInstance(objectStore, subFolder.getClassName(), null);
		   
		   // Get the property definition for SecurityPolicy.
		   // Helper method getPropertyDefinition not shown.
		    
		   // Get the Id of the SecurityObject to be removed.
		
		  /* SecurityPolicy spTarget = (SecurityPolicy) (subFolder.getProperties().get(PropertyNames.SUB_FOLDERS)).getObjectValue();
		   Id spTargetId = spTarget.get_Id();*/
		   
		   // Remove SecurityObject from the class.
		/*System.out.println(subFolder.getProperties().get(PropertyNames.SUB_FOLDERS.toString()).isSettable());
		   (subFolder.getProperties().get(PropertyNames.FOLDER_NAME.toString())).setObjectValue(AccessLevel.READ.getValue());
		   subFolder.save(RefreshMode.REFRESH);*/
		    
		   // Delete SecurityObject from the object store.
		  /* SecurityPolicySet sps = objectStore.get_SecurityPolicies();
		   Iterator outerIter = sps.iterator();
		   while (outerIter.hasNext())
		   {
		      SecurityPolicy sp = (SecurityPolicy) outerIter.next();
		      
		      if (sp.get_Id().equals(spTargetId) )
		      {
		          sp.delete();
		          sp.save(RefreshMode.REFRESH);
		      }
		   }*/

		
		return subFolder;
	}

	
	public void deleteFolder(Folder folder) {
		folder.delete();
		folder.save(RefreshMode.REFRESH);
		logger.info("Folder deleted");
		//System.out.println("Folder deleted");
	}

	
	public void printSubfolders(Folder folder) {
		FolderSet subfolders = folder.get_SubFolders();
		Iterator iterator = subfolders.iterator();
		
		logger.info("SUBFOLDERS: ");
		//System.out.println("SUBFOLDERS: ");
		while (iterator.hasNext()) {
			Folder next = (Folder) iterator.next();
			logger.info(next.get_Name());
			//System.out.println(next.get_Name());
		}
	}

	
	public void printDocuments(Folder folder) {
		DocumentSet docs = folder.get_ContainedDocuments();
		Iterator iterator = docs.iterator();

		logger.info("DOCUMENTS: ");
		//System.out.println("DOCUMENTS: ");
		while (iterator.hasNext()) {
			Document next = (Document) iterator.next();
			logger.info(next.get_Name());
			//System.out.println(next.get_Name());
		}
	}

	
	public void printObjects(Folder folder) {
		ReferentialContainmentRelationshipSet objects = folder.get_Containees();
		Iterator iterator = objects.iterator();

		logger.info("OBJECTS: ");
		//System.out.println("OBJECTS: ");
		while (iterator.hasNext()) {
			ReferentialContainmentRelationship next = (ReferentialContainmentRelationship) iterator.next();
			IndependentObject head = next.get_Head();
			logger.info(head.getClassName() + ":" + next.get_Name());
			//System.out.println(head.getClassName() + ":" + next.get_Name());
		}
	}

	private void cleanExistContexts() {
		com.filenet.api.util.UserContext ucCurrThread = com.filenet.api.util.UserContext.get();
		// clear the context of all credentials
		int popCnt = 0;
		while (ucCurrThread.popSubject() != null) {
			popCnt++;
		}
	}

	
	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#establish()
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public boolean establish() throws Exception
	{
		logger.info("establish()", "Establishing connection to " + this.ceURL + "");
		try {
			logger.info("establish()", "Before Establish Connection");
			this.domain = Factory.Domain.getInstance(this.conn, null);
			//this.domain = Factory.Domain.fetchInstance(this.conn, null,null);
			logger.info("establish()", "After Establish Connection");
			if (this.domain == null) {
			throw new Exception("Error while fetching domain object");
			}
			return true;
			}
		catch (Exception ex){
			ex.printStackTrace();
			logger.error("establish()", "Exception Caught while establishing connection "+ex);
			return false;
			}
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchObjectStore(java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public ObjectStore fetchObjectStore(String name) throws  Exception {

		if (name == null || name.length() == 0) {
			throw new Exception("Invalid objectstore name");
		}
		logger.info("Requesting ObjectStore :: " + name);
		//System.out.println("Requesting ObjectStore :: " + name);

		if (domain == null || this.conn == null) {
			throw new Exception("Establish connection first");
		}
		logger.info("fetchObjectStore()", "Before fetchObjectStore");
		//ObjectStore os = Factory.ObjectStore.fetchInstance(domain, name, null);
		ObjectStore os = Factory.ObjectStore.getInstance(domain, name);
		logger.info("fetchObjectStore()", "After fetchObjectStore");

		if (os == null) {
			throw new Exception("Objectstore not found");
		}
		//System.out.println("Returning ObjectStore " + os.get_SymbolicName() + " " + os.get_Id());
		return os;
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchFolder(java.lang.String, java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public Folder fetchFolder(String path, String os) throws Exception {
		if (os == null || os.isEmpty()) {
			throw new Exception("Object store name must be defined");
		}
		ObjectStore store = fetchObjectStore(os);

		return fetchFolder(path, store);
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchFolder(java.lang.String, com.filenet.api.core.ObjectStore)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public Folder fetchFolder(String path, ObjectStore os) throws Exception
	{
		try {
			logger.info("fetchFolder()", "Running search:\t"+path);
			//System.out.println("Running search:\t"+path);
			Folder folder=Factory.Folder.fetchInstance(os, path, null);
			logger.info("fetchFolder()", "Folder after"+folder.get_PathName());
			return folder;
			}
		catch (Exception e){
			e.printStackTrace();
			logger.error("fetchFolder()", "Exception caught while fetching Folder "+e);
			}
		return null;
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#search(java.lang.String, boolean, int, java.lang.String, java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public IndependentObjectSet search(String symbolicName, boolean includeSubClasses, int MaxRecords, String Where, String os) throws Exception {
		if (os == null || os.isEmpty()) {
            throw new Exception("Object store name must be defined");
        }
        
        ObjectStore store= this.fetchObjectStore(os);

        return search(symbolicName, includeSubClasses, MaxRecords, Where, store);
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#search(java.lang.String, boolean, int, java.lang.String, com.filenet.api.core.ObjectStore)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public IndependentObjectSet search(String symbolicName, boolean includeSubClasses, int MaxRecords, String Where, ObjectStore os) throws Exception {
		logger.info("Running search");
		//System.out.println("Running search");
        if (os == null) {
            throw new Exception("Object store name must be defined");
        }
        
         
        SearchScope search = new SearchScope(os);
        SearchSQL statement = new SearchSQL();
        statement.setFromClauseInitialValue(symbolicName, symbolicName, includeSubClasses);
        if (MaxRecords > 0) {
            statement.setMaxRecords(MaxRecords);
        }
        if (Where != null && Where.length() > 0) {
            statement.setWhereClause(Where);
        }
        IndependentObjectSet ObjectSet = (IndependentObjectSet) search.fetchObjects(statement, null, null, Boolean.valueOf(true));
        return ObjectSet;
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchDocument(java.lang.String, java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public Document fetchDocument(String id, String os) throws  Exception {
		if (os == null || os.isEmpty()) {
			throw new Exception("Object store name must be defined");
		}
		ObjectStore store = this.fetchObjectStore(os);
		return this.fetchDocument(new Id(id), store);
	}

	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchDocument(com.filenet.api.util.Id, com.filenet.api.core.ObjectStore)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public Document fetchDocument(Id id, ObjectStore os) throws  Exception {
		logger.info("Fetching document Id");
		//System.out.println("Fetching document Id");
        
        return Factory.Document.fetchInstance(os, id, null);
	}
	
	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#fetchDocument(java.lang.String, com.filenet.api.core.ObjectStore)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public Document fetchDocument(String path, ObjectStore os) throws Exception {
		logger.info("Fetching document");
		//System.out.println("Fetching document");
		return Factory.Document.fetchInstance(os, path, null);
	}

	/**
	 * Creates a new authentication subject
	 */
	private void createSubject(String username, String password, String stanza) {
		//System.out.println("this.conn:\t"+this.conn+"::"+username+"::"+password+"::"+stanza);
		UserContext uc = UserContext.get();
		Subject ss = UserContext.createSubject(this.conn, username, password, stanza);
		uc.pushSubject(ss);
		this.subject = ss;

	}

	
	/*public int getFileCount(Folder folder) {
		ReferentialContainmentRelationshipSet objects = folder.get_Containees();
		Iterator iterator = objects.iterator();
		int i = 0;
		while (iterator.hasNext()) {
			 i++;
			    iterator.next();
		}
		return i;
	}*/
	
	private void doFolder(Folder f) {
		try {
		Folder currFolder = f;
		logger.info("Folder: " + f.get_PathName() + " with ID " + f.get_Id().toString());

		//process this folder
		checkDocuments(f);

		//now process subfolders
		FolderSet fs = f.get_SubFolders();
		if(fs!=null)
		{
			Iterator ifs = fs.iterator();
			if(ifs!=null)
			{
				while (ifs.hasNext()) 
				{
					Folder nextFolder = (Folder)ifs.next();
					doFolder((Folder)nextFolder);
				}
			}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.error(this.getClass().getName(), "doFolder()", "Exception caught while doFolder "+e);
		}
		}

		public void checkDocuments(Folder folder) {
			int i=0;
			DocumentSet objects = folder.get_ContainedDocuments();
			if(objects!=null)
			{
					Iterator iterator = objects.iterator();
					if(iterator!=null)
					{
						while (iterator.hasNext()) 
						{
							docCount++;
							iterator.next();
						}
				}
			}
			logger.info("Count Documents:\t"+docCount);
		}
	
	public int getFileCount(Folder folder) {
		doFolder(folder);
		return docCount;
	}
	
	/*public boolean downloadFile (ObjectStore objectStore,String ubmFolderName, String baseDirectory, String folderName) throws Exception {
		

		List<String> fileIds = null;

		try
		{
			fileIds = getAllFilesInFolderFromP8Server(objectStore,ubmFolderName, folderName);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.logp(Level.ALL, this.getClass().getName(), "downloadFile()", "Exception caught while downloadFile "+e);
		}

		if (fileIds != null && fileIds.size() > 0)
		{
			String downloadDirectory = baseDirectory + folderName;
			File file = new File(downloadDirectory);
			if (!file.exists()) {
				file.mkdirs();
			}

			for (String eachId : fileIds) {
				Document doc = Factory.Document.fetchInstance(objectStore, new Id(eachId), null);
				ContentElementList contentList = doc.get_ContentElements();
				Iterator<ContentTransfer> iter = contentList.iterator();

				if (iter.hasNext()) {
					ContentTransfer ct = (ContentTransfer) iter.next();
					String mimeType = ct.get_ContentType();
					String documentName = ct.get_RetrievalName();
					InputStream inStream =  ct.accessContentStream();
					OutputStream outStream = null;

					logger.log(Level.ALL, "P8Helper:|:downloadFile():|:mimeType = " + mimeType);
					logger.log(Level.ALL, "P8Helper:|:downloadFile():|:folderName = " + folderName);
					logger.log(Level.ALL, "P8Helper:|:downloadFile():|:documentName = " + documentName);
					//System.out.println("P8Helper:|:downloadFile():|:mimeType = " + mimeType);
					//System.out.println("P8Helper:|:downloadFile():|:folderName = " + folderName);
					//System.out.println("P8Helper:|:downloadFile():|:documentName = " + documentName);

					try
					{
						outStream = new FileOutputStream(new File(baseDirectory + folderName + "/" + documentName));
						logger.log(Level.ALL, new File(baseDirectory + folderName + "/" + documentName).getAbsolutePath());
						//System.out.println(new File(baseDirectory + folderName + "/" + documentName).getAbsolutePath());
						byte[] buffer = new byte[4096];
						int bytesRead = -1;

						while ((bytesRead = inStream.read(buffer)) != -1) {
							outStream.write(buffer, 0, bytesRead);
						}
						inStream.close();
						outStream.close();
						
					}
					catch(Exception e)
					{
						e.printStackTrace();
						logger.logp(Level.ALL, this.getClass().getName(), "downloadFile()", "Exception caught while outStream "+e);
					}
					
				}
			}
		}
		return true;
	}*/
	
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#downloadFile(com.filenet.api.core.ObjectStore, java.lang.String, java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public File downloadFile (ObjectStore objectStore,String objectID, String outputFilePath) throws Exception {
		

		
		Document doc = Factory.Document.fetchInstance(objectStore, new Id(objectID), null);
		ContentElementList contentList = doc.get_ContentElements();
		Iterator<ContentTransfer> iter = contentList.iterator();

		File tempFile = null;
		String fileName = null;
		
		if (iter.hasNext()) {
			ContentTransfer ct = (ContentTransfer) iter.next();
			String mimeType = ct.get_ContentType();
			String documentName = ct.get_RetrievalName();
			InputStream inStream =  ct.accessContentStream();
			OutputStream outStream = null;

			logger.info("P8Helper:|:downloadFile():|:mimeType = " + mimeType);
			//logger.log(Level.ALL, "P8Helper:|:downloadFile():|:folderName = " + folderName);
			logger.info("P8Helper:|:downloadFile():|:documentName = " + documentName);
			//System.out.println("P8Helper:|:downloadFile():|:mimeType = " + mimeType);
			//System.out.println("P8Helper:|:downloadFile():|:folderName = " + folderName);
			//System.out.println("P8Helper:|:downloadFile():|:documentName = " + documentName);

			try
			{
				String separate= doc.get_Id().toString();
				//System.out.println("::: 1 Separeteed object {}::: "+separate);
				separate = separate.replaceAll("\\{", "");
				separate=separate.replaceAll("\\}", "");
				outStream = new FileOutputStream(new File(outputFilePath + "/" +separate+"_"+documentName));
				logger.info(new File(outputFilePath + "/" +separate+"_"+documentName).getAbsolutePath());
				//System.out.println(new File(baseDirectory + folderName + "/" + documentName).getAbsolutePath());
				byte[] buffer = new byte[4096];
				int bytesRead = -1;

				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				
				inStream.close();
				outStream.close();
				//tempFile= new File(outputFilePath + "/" + documentName);
				return new File(outputFilePath + "/" +separate+"_"+documentName);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger.info(this.getClass().getName(), "downloadFile()", "Exception caught while outStream "+e);
			}
			
		}


return null;
}
	/** (non-Javadoc)
	 * @see com.att.ubm.filenet.util.IFileNetConnector#downloadFileFromFileNet(com.filenet.api.core.ObjectStore, java.lang.String, java.lang.String)
	 * @throws
	 * @return
	 */
	@SuppressWarnings("all")
	public File downloadFileFromFileNet (ObjectStore objectStore,String objectID, String outputFilePath) throws Exception {
	
		Document doc = Factory.Document.fetchInstance(objectStore, new Id(objectID), null);
		ContentElementList contentList = doc.get_ContentElements();
		Iterator<ContentTransfer> iter = contentList.iterator();

		File tempFile = null;
		String fileName = null;
		
		if (iter.hasNext()) {
			ContentTransfer ct = (ContentTransfer) iter.next();
			String mimeType = ct.get_ContentType();
			String documentName = ct.get_RetrievalName();
			InputStream inStream =  ct.accessContentStream();
			OutputStream outStream = null;

			logger.info("P8Helper:|:downloadFile():|:mimeType = " + mimeType);
			logger.info("P8Helper:|:downloadFile():|:documentName = " + documentName);
			//System.out.println("P8Helper:|:downloadFile():|:mimeType = " + mimeType);
			//System.out.println("P8Helper:|:downloadFile():|:folderName = " + folderName);
			//System.out.println("P8Helper:|:downloadFile():|:documentName = " + documentName);

			try
			{
				//String separate= doc.get_Id().toString();
				//System.out.println("::: 1 Separeteed object {}::: "+separate);
				//separate = separate.replaceAll("\\{", "");
				//separate=separate.replaceAll("\\}", "");
				outStream = new FileOutputStream(new File(outputFilePath + "/" +documentName));
				logger.info(new File(outputFilePath + "/" + "_"+documentName).getAbsolutePath());
				//System.out.println(new File(baseDirectory + folderName + "/" + documentName).getAbsolutePath());
				byte[] buffer = new byte[4096];
				int bytesRead = -1;

				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				
				inStream.close();
				outStream.close();
				//tempFile= new File(outputFilePath + "/" + documentName);
				return new File(outputFilePath + "/" +documentName);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger.error("downloadFile()", "Exception caught while outStream "+e);
			}
			
		}
		return null;
}

	/**
	 * @param objectStore
	 * @param ubmFolderName
	 * @param folderName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public static List<String> getAllFilesInFolderFromP8Server(ObjectStore objectStore, String ubmFolderName,String folderName) throws Exception {
		List<String> fileIds = new ArrayList<String>();
		String childFolderPath = ubmFolderName +java.io.File.separator +folderName;
		Folder currentFolder = Factory.Folder.fetchInstance(objectStore, childFolderPath, null);
		Folder parent = currentFolder.get_Parent();

		DocumentSet ds = currentFolder.get_ContainedDocuments();
		Iterator dsIterator = ds.iterator();

		while (dsIterator.hasNext())
		{
			DocumentImpl di = (DocumentImpl)dsIterator.next();
			fileIds.add(di.get_Id().toString());
		}
		return fileIds;

	}

	@Override
	public Folder getPathByFolderID(String folderId,ObjectStore os) throws Exception {
		logger.info("getPathByFolderID");
		//System.out.println("getPathByFolderID");
        
        return Factory.Folder.fetchInstance(os, folderId, null);	
	}

	@Override
	public Folder getFolderObject(Id folderId, ObjectStore os) throws Exception {
		logger.info("getFolderObject:\t"+folderId);
		//System.out.println("getFolderObject:\t"+folderId);
		return Factory.Folder.fetchInstance(os, folderId, null);
	}
	
	@Override
	public List<Id> getAllFilesInFolder(ObjectStore objectStore, String folderObjectId) throws Exception {
		logger.info("getAllFilesInFolder:\t"+folderObjectId);
		List<Id> fileIds = new ArrayList<Id>();
		Id id=new Id(folderObjectId);
		Folder currentFolder = Factory.Folder.fetchInstance(objectStore, id, null);
		Folder parent = currentFolder.get_Parent();
		DocumentSet ds = currentFolder.get_ContainedDocuments();
		Iterator dsIterator = ds.iterator();
		while (dsIterator.hasNext())
		{
			DocumentImpl di = (DocumentImpl)dsIterator.next();
			fileIds.add(di.get_Id());
		}
		logger.info("getAllFilesInFolder Size:\t"+fileIds.size());
		return fileIds;
	}
	
	@Override
	public Map<String,String> getAllFileNamesAndId(ObjectStore objectStore, String folderObjectId) throws Exception {
		logger.info("getAllFileNamesInFolder:\t"+folderObjectId);
		Map<String,String> fileNames = new HashMap<String, String>();
		Id id=new Id(folderObjectId);
		Folder currentFolder = Factory.Folder.fetchInstance(objectStore, id, null);
		Folder parent = currentFolder.get_Parent();
		DocumentSet ds = currentFolder.get_ContainedDocuments();
		Iterator dsIterator = ds.iterator();
		while (dsIterator.hasNext())
		{
			DocumentImpl di = (DocumentImpl)dsIterator.next();
			fileNames.put(di.get_Id().toString(),di.get_Name());
		}
		logger.info("getAllFileNamesInFolder Size:\t"+fileNames.size());
		return fileNames;
	}
	
	public int getSubFolderFileCount(Folder folder) {
		logger.info("getSubFolderFileCount");
		int i=0;
		FolderSet sfs = folder.get_SubFolders();
		Iterator<Folder> it = sfs.iterator();
		Folder sf;
		while (it.hasNext()) {
		    sf = it.next();
		    System.out.println(sf.get_FolderName());
		}
		   return i;
		
	}
	
	/**
	 * @param id
	 * @param os
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public Folder fetchFolderById(String id, ObjectStore os) throws Exception
	{
		try {
			logger.info("fetchFolderById()", "Running search:\t"+id);
			//System.out.println("Running search:\t"+path);
			Folder folder=Factory.Folder.fetchInstance(os, new Id(id), null);
			logger.info("fetchFolderById()", "Folder after"+folder.get_PathName());
			return folder;
			}
		catch (Exception e){
			e.printStackTrace();
			logger.error("fetchFolderById()", "Exception caught while fetchFolderById Folder "+e);
			}
		return null;
	}
	
	@Override
	public List<Id> getAllFilesInFolderFromP8Server(ObjectStore objectStore, String folderObjectId) throws Exception {
		List<Id> fileIds = new ArrayList<Id>();
		System.out.println("P8Helper:|:getAllFilesInFolderFromP8Server():|:Before Fetch");
		Id id=new Id(folderObjectId);
		Folder currentFolder = Factory.Folder.fetchInstance(objectStore, id, null);
		Folder parent = currentFolder.get_Parent();
		System.out.println("P8Helper:|:getAllFilesInFolderFromP8Server():|:currentFolder = " + currentFolder);
		System.out.println("P8Helper:|:getAllFilesInFolderFromP8Server():|:parent = " + parent);

		DocumentSet ds = currentFolder.get_ContainedDocuments();
		Iterator dsIterator = ds.iterator();

		while (dsIterator.hasNext())
		{
			DocumentImpl di = (DocumentImpl)dsIterator.next();
			fileIds.add(di.get_Id());
		}
		return fileIds;

	}
	

}

