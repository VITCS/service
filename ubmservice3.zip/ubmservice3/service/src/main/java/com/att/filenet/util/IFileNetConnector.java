package com.att.filenet.util;


import java.io.File;
import java.util.List;
import java.util.Map;

import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Document;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;



/**
 * @author sm802k
 *
 */
public interface IFileNetConnector {
	
	/**
     * Establish connection to FileNet
     * @throws ConnNotEstablished  Throws a ConnNotEstablished exception if connection cannot be established
     */
	@SuppressWarnings("all")
    public boolean establish() throws Exception;
    
    /**
     * Fetch Object Store By Name
     * @param name Name of object store
     * @return Object Store
     * @throws InvalidArgument If Object Store name is empty or null
     * @throws Exception if object store is not found or cannot be fetched
     */
	@SuppressWarnings("all")
    public ObjectStore fetchObjectStore(String name) throws Exception;
    
    /**
     * @param objectStore
     * @param name
     * @param parent
     * @return
     */
	@SuppressWarnings("all")
    public Folder createFolder(ObjectStore objectStore,String name, Folder parent);

	void deleteFolder(Folder folder);
    
	void printSubfolders(Folder folder);

	void printDocuments(Folder folder);

	void printObjects(Folder folder);

    /**
     * Fetch Folder from Object Store by Object Store Name
     * @param path Path to fetched folder
     * @param os Object Store Name
     * @return Folder
     * @throws InvalidArgument
     * @throws Exception 
     */
	@SuppressWarnings("all")
    public Folder fetchFolder(String path, String os) throws Exception;
    
    /**
     * Fetch Folder from Object Store
     * @param path Path to Folder
     * @param os Object Store
     * @return Folder
     * @throws InvalidArgument
     * @throws Exception 
     */
	@SuppressWarnings("all")
     public Folder fetchFolder(String path,  ObjectStore os) throws Exception;
    
    /**
     * Run search the object store
     * @param symbolicName Symbolic name of searched object
     * @param includeSubClasses Include inherited classes 
     * @param MaxRecords Maximum number of records
     * @param Where Where condition
     * @param os ObjectStore name
     * @return IndependentObjectSet of matching objects
     * @throws Exception 
     */
	@SuppressWarnings("all")
    public IndependentObjectSet search(String symbolicName, boolean includeSubClasses, int MaxRecords, String Where, String os) throws Exception;

    /**
     * Run search the object store
     * @param symbolicName Symbolic name of searched object
     * @param includeSubClasses Include inherited classes 
     * @param MaxRecords Maximum number of records
     * @param Where Where condition
     * @param os ObjectStore
     * @return IndependentObjectSet of matching objects
     * @throws Exception 
     */
	@SuppressWarnings("all")
    public IndependentObjectSet search(String symbolicName, boolean includeSubClasses, int MaxRecords, String Where, ObjectStore os) throws Exception;
     
    /**
     * @param id
     * @param os
     * @return
     * @throws Exception
     */
	@SuppressWarnings("all")
    public Document fetchDocument(String id, String os) throws Exception;
    
    /**
     * Fetching Document using Id and Object Store
     * @param id Id 
     * @param os Object Store Name
     * @return Document
     * @throws InvalidArgument
     * @throws Exception 
     */
	@SuppressWarnings("all")
    public Document fetchDocument(Id id,  ObjectStore os) throws Exception;
    
    /**
     * @param path
     * @param os
     * @return
     * @throws Exception
     */
	@SuppressWarnings("all")
    public Document fetchDocument(String path,  ObjectStore os) throws Exception;
    
    int getFileCount(Folder folder);
    
    /**
     * @param objectStore
     * @param id
     * @param baseDirectory
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public File downloadFile(ObjectStore objectStore,String id, String baseDirectory) throws Exception;

    /**
     * @param objectStore
     * @param id
     * @param baseDirectory
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public File downloadFileFromFileNet(ObjectStore objectStore,String id, String baseDirectory) throws Exception;
    
    /**
     * @param folderId
     * @param os
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public Folder getPathByFolderID(String folderId,ObjectStore os) throws Exception;
    
    /**
     * @param folderId
     * @param os
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public Folder getFolderObject(Id folderId,ObjectStore os) throws Exception;
    
    /**
     * @param folder
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public int getSubFolderFileCount(Folder folder) throws Exception;
    
    /**
     * @param os
     * @param folderName
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public List<Id> getAllFilesInFolder(ObjectStore os,String folderName) throws Exception;
    
    /**
     * @param os
     * @param folderName
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public Map<String,String> getAllFileNamesAndId(ObjectStore os,String folderName) throws Exception;
    
    /**
     * @param objectStore
     * @param folderObjectId
     * @return
     * @throws Exception
     */
    @SuppressWarnings("all")
    public List<Id> getAllFilesInFolderFromP8Server(ObjectStore objectStore, String folderObjectId) throws Exception;

}

