package com.att.ubm.model;

import java.io.Serializable;

public class CamundaModel implements Serializable {
	
	private CamundaActionModel variables;
	private String businessKey;
	
	
	public CamundaActionModel getVariables() {
		return variables;
	}
	public void setVariables(CamundaActionModel variables) {
		this.variables = variables;
	}
	public String getBusinessKey() {
		return businessKey;
	}
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	
	

}
