package com.att.ubm.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.Validator;

public final class DecoratorDate
{

/*
NOTES:
------
1.  To convert a string to a time or timestamp value
		use -- stringToDateInFormat(str, "hh:mm:ss a", null) --


2.	To get time or timestamp value in string format
		use -- datetoString(date1, "hh:mm:ss a", null) --

		Note: You may also use dateToTimeString(date1, DateFormat.SHORT, null);


3.  To compare 2 dates
		use -- date1.equals( date2 ) --  // date1 == date2
		    -- date1.before( date2 ) --  // date1 < date2
		    -- date1.after ( date2 ) --  // date1 > date2


4.	To get individual component of date, such as, year, month, hour, minutes, etc.
		use -- dateToComponent(d1, Calendar.YEAR) --

		Note: using Calendar is highly suggested for performance
			Calendar c1 = dateToCalendar(d1);
			int iyear  = calendarToComponent( c1, Calendar.YEAR );
			int imonth = calendarToComponent( c1, Calendar.MONTH );



Performance Notes:
------------------
	Strings -> Date -> Strings
				|
				|<---> Calendar (should be used in programs to compare and
				|				 perform any date operation *)
				|
				|<---> java.sql.Date/Time/Timestamp (used with JDBC)

	* Though Date can also be used to perform date comparison and date operation,
	  Calendar is a preffered way for performance reasons.  This is because, Date
	  internally uses Calendar.

	  However, since Calendar is an abstract class we have to extend from it to
	  create a new class and implement 8 methods.  That being more complex,
	  we decided to use the above model.  (Do it in the future sometimes.)

*/
public static final String RATE_PLAN_DATE_FORMAT = "MM/dd/yyyy";
	
private DecoratorDate() {
	super();
}

public static final int calendarToComponent(Calendar calendar, int iComponentType)
{
	// e.g. iComponentType =
	//			Calendar.YEAR
	//			Calendar.MONTH
	//			Calendar.DAY_OF_MONTH
	//			Calendar.HOUR
	//			Calendar.MINUTE
	//			Calendar.SECOND
	//			Calendar.AM_PM

	if (iComponentType == Calendar.MONTH)
		return calendar.get(iComponentType) + 1;
	else
		return calendar.get(iComponentType);
}
public static final Date calendarToDate(Calendar calendar)
{
	if (calendar == null)
		return new Date(0);

	return calendar.getTime();
}

public static final Date dateAdd(Date date, int iComponentType, int iAmount)
{
	// e.g. iComponentType =
	//			Calendar.YEAR
	//			Calendar.MONTH
	//			Calendar.DAY_OF_MONTH
	//			Calendar.HOUR
	//			Calendar.MINUTE
	//			Calendar.SECOND
	//			Calendar.AM_PM

	if ( date == null )
		date = new Date(0);

	Calendar calendar = dateToCalendar(date);
	calendar.add(iComponentType, iAmount);
	return calendarToDate(calendar);
}

/**
 * Add iAmount days to the specified date. If the resulting day is a weekend, move to Monday
 * 
 * @param date - date to be moved by iAmount no. of days
 * @param iComponentType
 * @param iAmount
 * @return
 */
public static final Date dateAddResultOnWorkingDay(Date date, int iComponentType, int iAmount)
{
	// e.g. iComponentType =
	//			Calendar.YEAR
	//			Calendar.MONTH
	//			Calendar.DAY_OF_MONTH
	//			Calendar.HOUR
	//			Calendar.MINUTE
	//			Calendar.SECOND
	//			Calendar.AM_PM

	if ( date == null )
		date = new Date(0);

	Calendar calendar = dateToCalendar(date);
	calendar.add(iComponentType, iAmount);	
	
	if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
		calendar.add(Calendar.DATE, 2);
		
	} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
		calendar.add(Calendar.DATE, 1);
		
	}
	
	return calendarToDate(calendar);
}

public static final Calendar dateToCalendar(Date date)
{
	if ( date == null )
		date = new Date(0);


	Calendar calendar;

	calendar = Calendar.getInstance();
	calendar.setTime( date );

	return calendar;
}

public static final int dateToComponent(Date date, int iComponentType)
{
	// e.g. iComponentType =
	//			Calendar.YEAR
	//			Calendar.MONTH
	//			Calendar.DAY_OF_MONTH
	//			Calendar.HOUR
	//			Calendar.MINUTE
	//			Calendar.SECOND
	//			Calendar.AM_PM

	if ( date == null )
		date = new Date(0);


	Calendar calendar = dateToCalendar(date);
	return calendarToComponent(calendar, iComponentType);
}

public static final java.sql.Date dateToSQLDate(Date date)
{
	if ( date == null )
		date = new Date(0);


	java.sql.Date sqlDate;
	sqlDate = new java.sql.Date( date.getTime() );

	return sqlDate;
}

public static final java.sql.Time dateToSQLTime(Date date)
{
	if ( date == null )
		date = new Date(0);


	java.sql.Time sqlTime;
	sqlTime = new java.sql.Time( date.getTime() );

	return sqlTime;
}

public static final java.sql.Timestamp dateToSQLTimestamp(Date date)
{
	if ( date == null )
		date = new Date(0);


	java.sql.Timestamp sqlTimestamp;
	sqlTimestamp = new java.sql.Timestamp( date.getTime() );

	return sqlTimestamp;
}

public static final String dateToString(java.util.Date date, int iDtFormat, Locale locale)
{
	// Check if Date is valid
	if ( date == null )
		return ""; // no need to do new data that gives wrong data.
		//date = new Date(0);


	// if null set locale to default
	if (locale == null )
		locale = localeGetDefault();


	DateFormat dfDateFormat;

	// e.g. iDtFormat =
	// 			DateFormat.SHORT 	- 12.13.52
 	// 			DateFormat.MEDIUM 	- Jan 12, 1952
	// 			DateFormat.LONG 	- January 12, 1952 or 3:30:32pm
	// 			DateFormat.FULL 	- Tuesday, April 12, 1952 AD or 3:30:42pm PST.

	dfDateFormat = DateFormat.getDateInstance( iDtFormat, locale );
	dfDateFormat.setLenient( false );
	try
	{
		return dfDateFormat.format(date);
	}
	catch (Exception e)
	{
		return "";
	}

}

public static final String dateToStringInFormat(java.util.Date date, String sDtFormat, Locale locale)
{
	// Check if Date is valid
	if ( date == null )
		return ""; // no need to do new data that gives wrong data.
		//date = new Date(0);;


	// if null set locale to default
	if (locale == null )
		locale = localeGetDefault();


	// e.g. sDtFormat =
	//	 		"MM/dd/yyyy"
	//			"hh:mm:ss a"
	SimpleDateFormat sdfDateFormat = new SimpleDateFormat(sDtFormat, locale);
	sdfDateFormat.setLenient( false );
	try
	{
		return sdfDateFormat.format( date );
	}
	catch (Exception e)
	{
		return "";
	}

}

public static final String dateToTimeString(java.util.Date date, int iDtFormat, Locale locale)
{
	// Check if Date is valid
	if ( date == null )
		date = new Date(0);


	// if null set locale to default
	if (locale == null )
		locale = localeGetDefault();


	DateFormat dfDateFormat;

	// e.g. iDtFormat =
	// 			DateFormat.SHORT 	- 4:06 PM
 	// 			DateFormat.MEDIUM 	- 4:06:00 PM
	// 			DateFormat.LONG 	- 4:06:00 PM EST
	// 			DateFormat.FULL 	- 4:06:00 PM EST

	dfDateFormat = DateFormat.getTimeInstance( iDtFormat, locale );
	dfDateFormat.setLenient( false );
	try
	{
		return dfDateFormat.format(date);
	}
	catch (Exception e)
	{
		return "12:00";
	}

}

public static final java.util.Date getCurrentDateTimestamp()
{
	return new Date();
}

public static final boolean intToDateYMD(int iYear, int iMonth, int iDate, Date dtDate)
{
	String sFullDate = iYear  + "." +
					   iMonth + "." +
					   iDate;


	return stringToDateInFormat(sFullDate, dtDate, "yyyy.MM.dd", null);
}

public static final Locale localeGetDefault()
{
	return Locale.getDefault();
}

public static final Date sqlDateToDate(java.sql.Date sqlDate)
{
	// Check if Date is valid
	if ( sqlDate == null )
		return new Date(0);


	Date date = new Date( sqlDate.getTime() );
	return date;
}

public static final Date sqlTimestampToDate(java.sql.Timestamp sqlTimestamp)
{
	// Check if Timestamp is valid
	if ( sqlTimestamp == null )
		return new Date(0);


	Date date = new Date( sqlTimestamp.getTime() );
	return date;
}

public static final Date sqlTimeToDate(java.sql.Time sqlTime)
{
	// Check if Time is valid
	if ( sqlTime == null )
		return new Date(0);


	Date date = new Date( sqlTime.getTime() );
	return date;
}

public static final boolean stringToDate(String sDate, Date dtDate, Locale locale)
{
	// Check is sDate is valid
	if ( ! Validator.isValidString(sDate) )
		return false;


	// if null set locale to default
	if (locale == null )
		locale = localeGetDefault();


	Date dtTemp;
	DateFormat dfDateFormat;

	dfDateFormat = DateFormat.getDateInstance( DateFormat.SHORT, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sDate );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	dfDateFormat = DateFormat.getDateInstance( DateFormat.MEDIUM, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sDate );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	dfDateFormat = DateFormat.getDateInstance( DateFormat.LONG, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sDate );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	SimpleDateFormat sdfDateFormat = new SimpleDateFormat("MM-dd-yyyy", locale);
	sdfDateFormat.setLenient( false );
	try
	{
		dtTemp = sdfDateFormat.parse( sDate );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	return false;
}

public static final boolean stringToDateInFormat(String sDate, Date dtDate, String sFormat, Locale locale)
{
	// Check if sDate is valid
	if ( ! Validator.isValidString(sDate) )
		return false;


	// Check if sFormat is valid
	// e.g. sFormat =
	//			"MM/dd/yyyy"
	//			"hh:mm:ss a"
	if ( ! Validator.isValidString(sFormat) )
		return false;


	// if null set locale to default
	if (locale == null )
		locale = localeGetDefault();


	Date dtTemp;

	SimpleDateFormat sdfDateFormat = new SimpleDateFormat(sFormat, locale);
	sdfDateFormat.setLenient( false );
	try
	{
		dtTemp = sdfDateFormat.parse( sDate );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{
	}


	return false;
}

public static final boolean stringToDateYMD(String sYear, String sMonth, String sDate, Date dtDate)
{
	// Check if sDate is valid
	if ( ! Validator.isValidInteger(sYear)  ||
		 ! Validator.isValidInteger(sMonth) ||
		 ! Validator.isValidInteger(sDate)  )
		return false;


	String sFullDate = sYear  + "." +
					   sMonth + "." +
					   sDate;


	return stringToDateInFormat(sFullDate, dtDate, "yyyy.MM.dd", null);
}


public static final boolean stringToTime(String sTime, Date dtDate, Locale locale)
{

	// Check is str is not null
	if ( ! Validator.isValidString(sTime) )
		return false;


	// if null set locale to default
	if (locale == null )
		locale = DecoratorDate.localeGetDefault();


	Date dtTemp;
	DateFormat dfDateFormat;

	dfDateFormat = DateFormat.getTimeInstance( DateFormat.SHORT, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sTime );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	dfDateFormat = DateFormat.getTimeInstance( DateFormat.MEDIUM, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sTime );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	dfDateFormat = DateFormat.getTimeInstance( DateFormat.LONG, locale );
	dfDateFormat.setLenient( false );
	try
	{
		dtTemp = dfDateFormat.parse( sTime );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	SimpleDateFormat sdfDateFormat = new SimpleDateFormat("HH:mm:ss", locale);
	sdfDateFormat.setLenient( false );
	try
	{
		dtTemp = sdfDateFormat.parse( sTime );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}


	sdfDateFormat = new SimpleDateFormat("HH:mm", locale);
	sdfDateFormat.setLenient( false );
	try
	{
		dtTemp = sdfDateFormat.parse( sTime );
		dtDate.setTime( dtTemp.getTime() );
		return true;
	}
	catch (java.text.ParseException pes)
	{ // Check if it is entered in another format
	}

	return false;
}

public static final Timestamp stringToUBMImplDate(String sDate)
{
	return stringToUBMImplDateInFormat(sDate, "MM/dd/yyyy");
}

public static final Timestamp stringToUBMImplDateInFormat(String sDate, String sFormat)
{
	if (!Validator.isValidString(sDate))
		return null;
		
	java.util.Date tempDate = new java.util.Date();
	stringToDateInFormat(sDate, tempDate, sFormat, null);
	Timestamp ubmImplDate = DecoratorDate.dateToSQLTimestamp(tempDate);
	return ubmImplDate;
}

public static final Timestamp getTimeInDucsFormatDate(String sDate) throws Exception
{
	if (!Validator.isValidString(sDate))
		return null;
	
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	java.util.Date tempDate=formatter.parse(sDate);
	return new Timestamp(tempDate.getTime());
}

public static final String getFormatedDate(String effectiveDate,String sourceFormat,String targetFormat) throws ParseException
{ 
		String dbDate;
		if (null != effectiveDate && !effectiveDate.equalsIgnoreCase("")) {
			SimpleDateFormat format1 = new SimpleDateFormat(sourceFormat);
			SimpleDateFormat format2 = new SimpleDateFormat(targetFormat);
			Date date = null;
			try {
				date = format1.parse(effectiveDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}
			dbDate = format2.format(date);
		} else {
			dbDate = "";
		}
		return dbDate;
}
public final static String formatNumber(double dNumber, String sFormat)
{
	String sFormatted = "";

	// For some reason it still returns "0" so override it
	if ( sFormat.equals("#") && dNumber == 0 )
		return " ";


	DecimalFormat df = (DecimalFormat)DecimalFormat.getNumberInstance();
	df.applyPattern(sFormat);
	sFormatted =  df.format(dNumber);

	return sFormatted;
}

}
