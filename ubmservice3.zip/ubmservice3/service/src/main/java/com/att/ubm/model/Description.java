/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class Description implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5227175126227549649L;

	private String sidId;

	private String sidDescription;

	private String sidType;

	private String creator;

	private String actionTaken;

	private String requestor;

	private String requestType;

	public Description() {

	}

	public String getSidId() {
		return sidId;
	}

	public void setSidId(String sidId) {
		this.sidId = sidId;
	}

	public String getSidDescription() {
		return sidDescription;
	}

	public void setSidDescription(String sidDescription) {
		this.sidDescription = sidDescription;
	}

	public String getSidType() {
		return sidType;
	}

	public void setSidType(String sidType) {
		this.sidType = sidType;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
