package com.att.ubm.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IMyTaskDAO;
import com.att.ubm.model.MyTasksModel;
import org.springframework.beans.factory.annotation.Qualifier;


@Repository
public class MyTaskDAOImpl implements IMyTaskDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	
	
	


	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}


	@Override
	public MyTasksModel getTaskInfo(String sidId){
		 
 
		String sql = "select * From t_taskinfo where id=?";
		try {
			return jdbcTemplate.queryForObject(sql,new Object[]{sidId}, new MyTasksModelRowMapper());
			}
			
		catch (Exception e) {
			e.printStackTrace();
		}
		return null; 
	}


	class MyTasksModelRowMapper implements RowMapper<MyTasksModel>
	
		{
	
		    @Override
	
		    public MyTasksModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		    	MyTasksModel task = new MyTasksModel();
		    	task.setNo(rs.getLong("id"));
		    	task.setTaskName(rs.getString("taskname"));
		    	task.setCreator(rs.getString("Creator"));
		    	task.setRequestType(rs.getString("requestType"));
		    	task.setSidId(rs.getString("sidid"));
		    	task.setSidDescription(rs.getString("siddescription"));
		    	task.setRequestNumber(rs.getString("request"));
		    	task.setImpactedGroupName(rs.getString("impactedgroupname"));
		    	task.setAssignmentDate(rs.getString("start_date"));
		    	task.setDueDate(rs.getString("end_date"));
		        return task;
	
		    }
	
		}
	
	

}
