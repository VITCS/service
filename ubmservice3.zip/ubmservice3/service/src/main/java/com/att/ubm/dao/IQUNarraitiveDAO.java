/**
 * 
 */
package com.att.ubm.dao;

import java.util.List;
import java.util.Map;

import com.att.ubm.model.ApprovalName;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.QUNarrativeModel;

/**
 * @author kb942m
 *
 */
public interface IQUNarraitiveDAO {

	public Map<String, ApprovalOption>  getApproverOptions();
	public int deleteMultiSelectRow(String tName,String sidId);
	public QUNarrativeModel getNarrativeFormValues(String sidId);
	public int insertNarrativeForm(String tableName,QUNarrativeModel quNarrativeModel);
	public int insertMultiSelects(String tabName,String sidId,String listName,List<String> values,String creator);
	public boolean rowExists(String tName,String sidId);
	public int updateNarrativeForm(String tableName,String query,Map<String,Object> paramValues);
	public Map<String,String> getJsonDBMapping(String sidType);
	public Map<String,String> getMultiSelectJsonIgnoreColumns(String sidType);
    public String getColumnValueFromSidNarr(String sidId,String columnName);
<<<<<<< HEAD
=======
    public int saveUBMRequest(String tableName, String sidId,String activityName,String jsonString,String userId) throws Exception;
    public int saveUBMResponse(String tableName, String sidId,String activityName,String responseText, String errorDesc) throws Exception;
    public Map<String,String> getErrorCodes();
    public List getMultISelectValues(String sidId,String columnName);
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
}
