/**
 * 
 */
package com.att.ubm.util;

import org.apache.commons.lang.StringUtils;

import com.att.ubm.model.Description;

/**
 * @author kb942m
 *
 */
public class DescriptionTokenUtil {

	public static Description getDescriptionToken(String tokenLst) {

		Description description = new Description();
		if(tokenLst != null && !tokenLst.isEmpty()){
		String[] tokenArr = StringUtils.split(tokenLst, ',');
		for (String myTaskInfoToken : tokenArr) {
			String[] splitToken = StringUtils.split(myTaskInfoToken, '=');
			
				if (splitToken[0].equals("SidId") && (splitToken.length > 1)) {
						description.setSidId(splitToken[1]);
				} else if (splitToken[0].equals("SidDesc") && (splitToken.length > 1)) {
					description.setSidDescription(splitToken[1]);
				} else if (splitToken[0].equals("SidType") && (splitToken.length > 1)) {
					description.setSidType(splitToken[1]);
				} else if (splitToken[0].equals("Creator") && (splitToken.length > 1)) {
					description.setCreator(splitToken[1]);
				} else if (splitToken[0].equals("RequestType") && (splitToken.length > 1)) {
					description.setRequestType(splitToken[1]);
				}
	       

		}
	 }

		return description;
	}

}
