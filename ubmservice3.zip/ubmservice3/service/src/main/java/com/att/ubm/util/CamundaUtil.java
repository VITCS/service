/**
 * 
 */
package com.att.ubm.util;

/**
 * @author kb942m
 *
 */
public class CamundaUtil {
	
	public static String CamundaURL = "CamundaURL";
	public static String CamundaURLPath = "/restservices";

}
