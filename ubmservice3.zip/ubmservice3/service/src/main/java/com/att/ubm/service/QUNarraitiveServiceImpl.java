/**
 * 
 */
package com.att.ubm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.att.ubm.camunda.CamundaUBMComponent;
import com.att.ubm.dao.IQUNarraitiveDAO;
import com.att.ubm.model.AlternateName;
import com.att.ubm.model.ApprovalName;
import com.att.ubm.model.ApprovalOption;
import com.att.ubm.model.CamundaActionModel;
import com.att.ubm.model.CamundaModel;
import com.att.ubm.model.ChannelName;
import com.att.ubm.model.ProductName;
import com.att.ubm.model.QUNarrativeModel;
import com.att.ubm.model.QuickUpdate;
import com.att.ubm.model.Voice;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.QUNarrativeConstants;
import com.att.aft.dme2.internal.jettison.json.JSONArray;
import com.att.it.tdc.bpm.domain.TaskData;
import com.att.it.tdc.bpm.domain.TaskDataMap;
import com.att.it.tdc.bpm.service.task.ITaskService;
import com.att.it.tdc.bpm.service.task.impl.TaskServiceCamundaImpl;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.DeserializationFeature;

import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;

/**
 * @author kb942m
 *
 */
@Service(value = "quNarraitiveService")
public class QUNarraitiveServiceImpl implements IQUNarraitiveService {

	private static final Logger logger = LoggerFactory.getLogger(QUNarraitiveServiceImpl.class);
	private String VALUE="value";
	private String TYPE="type";
	Map<String,String> errorCodes=null;

	@Autowired
	IQUNarraitiveDAO quNarraitiveDAO;
	
	@Autowired
	CamundaUBMComponent camundaComponent; 
	
	@Autowired
	@Qualifier("ubmTransactionManager")
	DataSourceTransactionManager ubmTransactionManager;
	
	@PostConstruct
	public void initIt() throws Exception {
		logger.info("Init method after properties are set in QUNarraitiveServiceImpl ");
		errorCodes=quNarraitiveDAO.getErrorCodes();
	}
	
	@Override
	public ApprovalOption getApproverOptionsInfo( List<ApprovalName> approvalNameMapList, String sidType,
			String sidId) {
		ApprovalOption approvalOption = null;
		QuickUpdate quickUpdate = null;
		Voice voice = null;
		List<ProductName> productNameList = new ArrayList<ProductName>();
		List<ChannelName> channelNameList = new ArrayList<ChannelName>();
		List<AlternateName> alternateNameList = new ArrayList<AlternateName>();
		ProductName productName = null;
		ChannelName channelName = null;
		AlternateName alternateName = null;
		String apprName = "";
		try {
			approvalOption = new ApprovalOption();
			quickUpdate = new QuickUpdate();	
			voice = new Voice();
			String name = "";
		if (approvalNameMapList != null && !approvalNameMapList.isEmpty()) {
			for (ApprovalName approvalNameModel : approvalNameMapList) {
				/*if (Long.parseLong(sidId) >= approvalNameModel.getStartDisplay()
						&& Long.parseLong(sidId) <= approvalNameModel.getEndDisplay()) {*/
					apprName = approvalNameModel.getName().substring(0, 7);
					if (approvalNameModel.getName() != null && !approvalNameModel.getName().isEmpty()) {
						name = approvalNameModel.getName().substring(8);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.PRODUCT)) {
						productName = new ProductName();
						productName.setFirstName(approvalNameModel.getFirstName());
						productName.setLastName(approvalNameModel.getLastName());
						productName.setUserName(approvalNameModel.getAttId());
						productName.setName(name);
						productNameList.add(productName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.CHANNEL)) {

						channelName = new ChannelName();
						channelName.setFirstName(approvalNameModel.getFirstName());
						channelName.setLastName(approvalNameModel.getLastName());
						channelName.setUserName(approvalNameModel.getAttId());
						channelName.setName(name);
						channelNameList.add(channelName);
					}
					if (apprName != null && apprName.equals(QUNarrativeConstants.ALTERNATE)) {
						apprName = approvalNameModel.getName().substring(0, 9);	
						alternateName = new AlternateName();
						alternateName.setFirstName(approvalNameModel.getFirstName());
						alternateName.setLastName(approvalNameModel.getLastName());
						alternateName.setUserName(approvalNameModel.getAttId());
						alternateName.setName(name);
						alternateNameList.add(alternateName);
					}
				//}
				if(sidType.equalsIgnoreCase("Quick Update")){
					quickUpdate.setProduct(productNameList);
					quickUpdate.setChannel(channelNameList);
					quickUpdate.setAlternate(alternateNameList);				
					approvalOption.setQuickUpdate(quickUpdate);
				}else if(sidType.equalsIgnoreCase("Voice")){					
					voice.setProduct(productNameList);
					voice.setChannel(channelNameList);
					voice.setAlternate(alternateNameList);				
					approvalOption.setVoice(voice);
				}
				
			}
			
		}
		
	}catch (Exception e) {
		logger.error("Exception={}", e.getMessage(), e);
	}
		
		return approvalOption;
	}

	@Override
	public String saveNarrativeForm(String quNarrativeString) {
		 int retVal=0;
		 boolean camundaFlag=false;
		 String errorCode="";
		 String responseMessage="";
		 String sidId="";
		 String activityName="";
		 String userId="";
		 //TransactionDefinition txDef=null;
		 //TransactionStatus txStatus=null;
		try {
			if(quNarrativeString!=null)
			{
				/* JSONArray jsonArr = new JSONArray(quNarrativeString);
				 //System.out.println("Json array:\t"+jsonArr.get(0).toString());
				 ObjectMapper objectMapper = new ObjectMapper();
					objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
					objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
					 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				 QUNarrativeModel baseJsonString=objectMapper.readValue(jsonArr.get(0).toString(),QUNarrativeModel.class);
				 QUNarrativeModel newJsonString=objectMapper.readValue(jsonArr.get(1).toString(),QUNarrativeModel.class);
				 JsonNode expectedNode = objectMapper.readTree(objectMapper.writeValueAsString(baseJsonString));
					JsonNode actualNode = objectMapper.readTree(objectMapper.writeValueAsString(newJsonString));
					//boolean areEqual = expectedNode.equals(actualNode);
					//System.out.println(areEqual);
					JSONCompareResult result = 
						     JSONCompare.compareJSON(jsonArr.get(0).toString(), jsonArr.get(1).toString(), JSONCompareMode.STRICT);
						System.out.println(result.toString());*/
				JSONArray jsonArr = new JSONArray(quNarrativeString);
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
				 QUNarrativeModel quNarrativeModel=null;
				 System.out.println(jsonArr.length()+"::::::::::::::::::::");
				
				 if(jsonArr.length()>0)
				 {
					 
					 quNarrativeModel=objectMapper.readValue(jsonArr.get(1).toString(), QUNarrativeModel.class);
					
					 sidId=quNarrativeModel.getSidId();
					 activityName=quNarrativeModel.getActivity();
					 userId=quNarrativeModel.getUserIdTakingAction();
				 }
				if(quNarrativeModel!=null && !quNarraitiveDAO.rowExists(QUNarrativeConstants.QU_TABLE_NAME, quNarrativeModel.getSidId()))
				{
					//txDef = new DefaultTransactionDefinition();
					//txStatus = ubmTransactionManager.getTransaction(txDef);
					System.out.println("getRequestedDate:\t"+quNarrativeModel.getNarrative().getRequestedDate());
					retVal=quNarraitiveDAO.insertNarrativeForm(QUNarrativeConstants.QU_TABLE_NAME,quNarrativeModel);
					if(retVal>0)
					{
						
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "MARKETS", quNarrativeModel.getNarrative().getMarkets(),quNarrativeModel.getCreator());
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "REQUIRED APPROVER", quNarrativeModel.getNarrative().getRequiredCoreApproval(),quNarrativeModel.getCreator());
					quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "OPTIONAL APPROVER", quNarrativeModel.getNarrative().getProductApprovers(),quNarrativeModel.getCreator());
<<<<<<< HEAD
					}
=======
					
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
					camundaFlag=makePostCall(quNarrativeModel);
					//camundaFlag=false;
					System.out.println("Camunda Api call status:\t"+camundaFlag);
					if(camundaFlag)
					{
						//ubmTransactionManager.commit(txStatus);
						responseMessage=QUNarrativeConstants.UBM_SUCCESS_RESPONSE_TEXT.replace("<ActivityName>", quNarrativeModel.getActivity());
						quNarraitiveDAO.saveUBMResponse(QUNarrativeConstants.UBM_REP_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), responseMessage,"");
						return responseMessage;
						
					}
					else
					{
						//ubmTransactionManager.rollback(txStatus);
						errorCode="ERR-001";
						responseMessage=QUNarrativeConstants.UBM_ERROR_RESPONSE_TEXT.replace("<ErrorCode>", errorCode);
						quNarraitiveDAO.saveUBMRequest(QUNarrativeConstants.UBM_REQ_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), quNarrativeString,quNarrativeModel.getUserIdTakingAction());
						quNarraitiveDAO.saveUBMResponse(QUNarrativeConstants.UBM_REP_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), responseMessage,errorCodes.get(errorCode));
						return responseMessage;
					}
					
					}
					
					
				}
				else
				{
					System.out.println("Record exists");

					if(quNarrativeModel!=null)
					{
						String baseString=jsonArr.get(0).toString();
						System.out.println("baseString:\t"+baseString);
						String userModifeidString=jsonArr.get(1).toString();
						System.out.println("userModifeidString:\t"+userModifeidString);
						JSONCompareResult result = 
						     JSONCompare.compareJSON(removeMultiselectArray(quNarrativeModel.getSidType(),userModifeidString),removeMultiselectArray(quNarrativeModel.getSidType(),baseString), JSONCompareMode.STRICT);
						if(result!=null)
						{
								List<FieldComparisonFailure> diffValues=result.getFieldFailures();
								if(diffValues!=null && diffValues.size()>0)
								{
									Map<String,String> jsonDbMapping=quNarraitiveDAO.getJsonDBMapping(quNarrativeModel.getSidType());
									Map<String,Object> updateNarrativeParams=new LinkedHashMap<String,Object>();
									StringBuffer sb=new StringBuffer("update SID_NARR set ");
									StringBuffer tempSb=new StringBuffer();
										for(FieldComparisonFailure obj:diffValues)
										{
											System.out.println("FieldName:\t"+obj.getField());
											System.out.println("Actual:\t"+obj.getActual());
											System.out.println("Expected:\t"+obj.getExpected());
											if(jsonDbMapping!=null && jsonDbMapping.size()>0 && jsonDbMapping.containsKey(obj.getField()))
											{
												if(obj.getField()!=null && (obj.getField()).endsWith("Date") || obj.getField().endsWith("date"))
												{
													updateNarrativeParams.put(jsonDbMapping.get(obj.getField()),DecoratorDate.stringToUBMImplDate((String)obj.getExpected()));
												}
												else
												{
												updateNarrativeParams.put(jsonDbMapping.get(obj.getField()), obj.getExpected());
												}
												sb.append(jsonDbMapping.get(obj.getField())+"=:"+jsonDbMapping.get(obj.getField()));
												sb.append(",");
											}
										}
										System.out.println(sb+"::::::::");
										tempSb.append(sb.toString().endsWith(",") ? sb.substring(0, sb.length()-1): sb.toString());
										//String testStr=tempStr+" where SID_ID="+Long.parseLong(quNarrativeModel.getSidId())+ " and SID_TYPE='"+quNarrativeModel.getSidType()+"' and REQ_TYPE='"+quNarrativeModel.getSidReqType()+"'";
										tempSb.append(" where SID_ID=:SID_ID and SID_TYPE=:SID_TYPE and REQ_TYPE=:REQ_TYPE");
										System.out.println("sb:\t"+tempSb.toString());
										updateNarrativeParams.put("SID_ID", Long.parseLong(quNarrativeModel.getSidId()));
										updateNarrativeParams.put("SID_TYPE", quNarrativeModel.getSidType());
										updateNarrativeParams.put("REQ_TYPE", quNarrativeModel.getSidReqType());
										//txDef = new DefaultTransactionDefinition();
										//txStatus = ubmTransactionManager.getTransaction(txDef);
										retVal=quNarraitiveDAO.updateNarrativeForm("SID_NARR", tempSb.toString(),updateNarrativeParams); 	
										//both insert and update narrative method make as a single method in furture
											if(retVal>0)
											{
											quNarraitiveDAO.deleteMultiSelectRow(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "MARKETS", quNarrativeModel.getNarrative().getMarkets(),quNarrativeModel.getCreator());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "REQUIRED APPROVER", quNarrativeModel.getNarrative().getRequiredCoreApproval(),quNarrativeModel.getCreator());
											quNarraitiveDAO.insertMultiSelects(QUNarrativeConstants.QU_LIST_TABLE_NAME, quNarrativeModel.getSidId(), "OPTIONAL APPROVER", quNarrativeModel.getNarrative().getProductApprovers(),quNarrativeModel.getCreator());
<<<<<<< HEAD
=======
											camundaFlag=makePostCall(quNarrativeModel);
											System.out.println("Camunda Api call status:\t"+camundaFlag);
											if(camundaFlag)
											{
												//ubmTransactionManager.commit(txStatus);
												responseMessage=QUNarrativeConstants.UBM_SUCCESS_RESPONSE_TEXT.replace("<ActivityName>", quNarrativeModel.getActivity());
												quNarraitiveDAO.saveUBMResponse(QUNarrativeConstants.UBM_REP_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), responseMessage,"");
												return responseMessage;
											}
											else
											{
												//ubmTransactionManager.rollback(txStatus);
												errorCode="ERR-001";
												responseMessage=QUNarrativeConstants.UBM_ERROR_RESPONSE_TEXT.replace("<ErrorCode>", errorCode);
												quNarraitiveDAO.saveUBMRequest(QUNarrativeConstants.UBM_REQ_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), quNarrativeString,quNarrativeModel.getUserIdTakingAction());
												quNarraitiveDAO.saveUBMResponse(QUNarrativeConstants.UBM_REP_TABLE_NAME, quNarrativeModel.getSidId(), quNarrativeModel.getActivity(), responseMessage,errorCodes.get(errorCode));
												return responseMessage;
											}
											}
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git
										
										}
									
								
								
								}
					
						}
					
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			if(retVal==0)
			{
				errorCode="ERR-002";
			}
			else if(camundaFlag==false)
			{
				errorCode="ERR-001";
			}
			//if(txStatus!=null)
				 //ubmTransactionManager.rollback(txStatus);
			logger.error("Exception={} in Sidid::"+sidId+"::activityName::"+activityName+"::errorCode::"+errorCodes.get(errorCode), e.getMessage(), e);
			responseMessage=QUNarrativeConstants.UBM_ERROR_RESPONSE_TEXT.replace("<ErrorCode>", errorCode);
			try {
				quNarraitiveDAO.saveUBMRequest(QUNarrativeConstants.UBM_REQ_TABLE_NAME,sidId , activityName, quNarrativeString,userId);
				quNarraitiveDAO.saveUBMResponse(QUNarrativeConstants.UBM_REP_TABLE_NAME, sidId, activityName, responseMessage,errorCodes.get(errorCode));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			return responseMessage;
		}
		return null;

	}
	@Override
	public QUNarrativeModel getNarrativeFormValues(String sidId) {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		 QUNarrativeModel quNarrativeModel=quNarraitiveDAO.getNarrativeFormValues(sidId);
		 String quNarrativeModelString=null;
		/*try {
			quNarrativeModelString = objectMapper.writeValueAsString(quNarrativeModel);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
			if(quNarrativeModel!=null)
			{
				System.out.println("getRequestedDate:\t"+quNarrativeModelString);
			}*/
			return quNarrativeModel;
	}
	
	private String removeMultiselectArray(String sidType,String orginalString) throws Exception
	{
		Map<String,String> listOfJsonListName=quNarraitiveDAO.getMultiSelectJsonIgnoreColumns(sidType);
		org.json.JSONObject beforeJo=new org.json.JSONObject(orginalString);
		if(listOfJsonListName!=null)
		{
		for ( String key : listOfJsonListName.keySet() ) {
			beforeJo.remove(key);
		}
		}
		
		
		return beforeJo.toString();
	}
	
	public String camundaApiService(QUNarrativeModel quNarrativeModel) {
		CamundaModel model=new CamundaModel();
		CamundaActionModel camundaActionModel=new CamundaActionModel();
		camundaActionModel.setActionTaken(mappingPostSubmit(quNarrativeModel.getActionTaken()));
		if(quNarrativeModel.getNarrative().getRequestorName()!=null && quNarrativeModel.getNarrative().getRequestorName().contains(":"))
		{
			String requestorId=quNarrativeModel.getNarrative().getRequestorName().split(":")[1];
			camundaActionModel.setRequestor(mappingPostSubmit(requestorId));
		}
		else
		{
		camundaActionModel.setRequestor(mappingPostSubmit(null));
		}
		camundaActionModel.setCreator(mappingPostSubmit(quNarrativeModel.getUserIdTakingAction()));
		camundaActionModel.setSidId(mappingPostSubmit(quNarrativeModel.getSidId()));
		camundaActionModel.setSidDesc(mappingPostSubmit(quNarrativeModel.getSidDescription()));
		camundaActionModel.setSidType(mappingPostSubmit(quNarrativeModel.getSidType()));
		camundaActionModel.setRequestType(mappingPostSubmit(quNarrativeModel.getSidReqType()));
		model.setVariables(camundaActionModel);
		model.setBusinessKey(quNarrativeModel.getSidId());
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		 String camundaJsonString=null;
		 
		try {
			camundaJsonString = objectMapper.writeValueAsString(model);
			if(camundaJsonString!=null && camundaJsonString.length()>0)
				return camundaJsonString;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public Map<String,String> mappingPostSubmit(String value)
	{
		Map<String,String> map=new HashMap<String,String>();
		map.put(VALUE, value);
		map.put(TYPE, "String");
		return map;
	}
	
	private boolean makePostCall(QUNarrativeModel quNarrativeModel)
	{
		try {
			ITaskService taskService = new TaskServiceCamundaImpl();
			taskService = camundaComponent.getCamundaTaskService("vs252n");
			boolean ret =false;
			if(quNarrativeModel!=null)
			{
				String camundaJsonStr=null;
				if(quNarrativeModel.getActivity()!=null && quNarrativeModel.getActivity().equals("Start"))
				{
					camundaJsonStr=camundaApiService(quNarrativeModel);
					System.out.println("Value of JSON request :::::::::::::: " + camundaJsonStr);
					ret = taskService.start("mobility", camundaJsonStr);	
					System.out.println(ret);
					return ret;
				}
				else if(quNarrativeModel.getActivity()!=null && !quNarrativeModel.getActionTaken().matches("Save|Cancel"))
				{
					TaskDataMap taskDataMap = new TaskDataMap();
					TaskData taskData=new TaskData();
					Map<String,TaskData> variables=new HashMap<String,TaskData>();
					taskData.setValue(quNarrativeModel.getActionTaken());
					taskData.setType("String");
					variables.put("actionTaken", taskData);
					taskData=new TaskData();
					taskData.setValue(quNarrativeModel.getUserIdTakingAction());
					variables.put("actionTakenBy ", taskData);
					taskData.setType("String");
					taskDataMap.setVariables(variables);
					ret = taskService.complete(quNarrativeModel.getTaskId(), taskDataMap);
					return ret;
						
					
						
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String getColumnValueFromSidNarr(String sidId, String columnName) {
		// TODO Auto-generated method stub
		String retVal=quNarraitiveDAO.getColumnValueFromSidNarr(sidId, columnName);
		return retVal;
	}
<<<<<<< HEAD
=======
	
	public String camundaApiNonStartString(QUNarrativeModel quNarrativeModel) {
		CamundaModel model=new CamundaModel();
		CamundaActionModel camundaActionModel=new CamundaActionModel();
		camundaActionModel.setActionTaken(mappingPostSubmit(quNarrativeModel.getActionTaken()));
		if(quNarrativeModel.getNarrative().getRequestorName()!=null && quNarrativeModel.getNarrative().getRequestorName().contains(":"))
		{
			String requestorId=quNarrativeModel.getNarrative().getRequestorName().split(":")[1];
			camundaActionModel.setRequestor(mappingPostSubmit(requestorId));
		}
		else
		{
		camundaActionModel.setRequestor(mappingPostSubmit(null));
		}
		camundaActionModel.setCreator(mappingPostSubmit(quNarrativeModel.getUserIdTakingAction()));
		camundaActionModel.setSidId(mappingPostSubmit(quNarrativeModel.getSidId()));
		camundaActionModel.setSidDesc(mappingPostSubmit(quNarrativeModel.getSidDescription()));
		camundaActionModel.setSidType(mappingPostSubmit(quNarrativeModel.getSidType()));
		camundaActionModel.setRequestType(mappingPostSubmit(quNarrativeModel.getSidReqType()));
		model.setVariables(camundaActionModel);
		model.setBusinessKey(quNarrativeModel.getSidId());
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		 objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		 String camundaJsonString=null;
		 
		try {
			camundaJsonString = objectMapper.writeValueAsString(model);
			if(camundaJsonString!=null && camundaJsonString.length()>0)
				return camundaJsonString;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	
	@Override
	public List getOptionalApproversForSid(String sidId) {
		// TODO Auto-generated method stub
		List optionalApprover = quNarraitiveDAO.getMultISelectValues(sidId, "OPTIONAL APPROVER");
		List retVal = new ArrayList<>();
		for (Object temp : optionalApprover) {
			System.out.println("Value ofsubString :::::::::::::: " + temp.toString().substring(temp.toString().lastIndexOf(":")) );
			// Check to eleminate duplicate insertion into list
			if (!retVal.contains(temp.toString().substring(temp.toString().lastIndexOf(":")+1))) {
				retVal.add(temp.toString().substring(temp.toString().lastIndexOf(":")+1));
			}	
		}
		
		return retVal;
	}
	
>>>>>>> branch 'master' of https://lj7014@codecloud.web.att.com/scm/st_ubm/ubmservice3.git

}
