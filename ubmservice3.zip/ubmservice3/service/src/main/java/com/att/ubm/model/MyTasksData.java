/**
 * 
 */
package com.att.ubm.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author kb942m
 *
 */
public class MyTasksData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5537342082477567542L;
	
	private List<MyTaskInfo> data;

	public List<MyTaskInfo> getData() {
		return data;
	}

	public void setData(List<MyTaskInfo> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
