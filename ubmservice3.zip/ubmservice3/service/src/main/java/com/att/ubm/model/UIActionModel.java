package com.att.ubm.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class UIActionModel {
	
	@JsonIgnore
	private String sidType;
	@JsonIgnore
	private String activityName;
	@JsonIgnore
	private String pageName;
	@JsonIgnore
	private String actionName;
	@JsonIgnore
	private int actionId;
	private boolean actionEnabled;
	private boolean actionVisibility;
	
	/*private Map<String,Object> actionEnabled;
	private Map<String,Object> actionVisibility;*/
	
	public String getSidType() {
		return sidType;
	}
	public void setSidType(String sidType) {
		this.sidType = sidType;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getActionName() {
		return actionName;
	}
	public void setActionName(String actionName) {
		this.actionName = actionName;
	}
	public int getActionId() {
		return actionId;
	}
	public void setActionId(int actionId) {
		this.actionId = actionId;
	}
	public boolean isActionEnabled() {
		return actionEnabled;
	}
	public void setActionEnabled(boolean actionEnabled) {
		this.actionEnabled = actionEnabled;
	}
	public boolean isActionVisibility() {
		return actionVisibility;
	}
	public void setActionVisibility(boolean actionVisibility) {
		this.actionVisibility = actionVisibility;
	}
	
	/*public Map<String, Object> getActionEnabled() {
		return actionEnabled;
	}
	public void setActionEnabled(Map<String, Object> actionEnabled) {
		this.actionEnabled = actionEnabled;
	}
	public Map<String, Object> getActionVisibility() {
		return actionVisibility;
	}
	public void setActionVisibility(Map<String, Object> actionVisibility) {
		this.actionVisibility = actionVisibility;
	}*/
	
	

}
