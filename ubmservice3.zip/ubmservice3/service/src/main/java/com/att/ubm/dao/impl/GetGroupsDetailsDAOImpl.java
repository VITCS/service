package com.att.ubm.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.att.ubm.dao.IGetGroupsDetailsDAO;
import com.att.ubm.dao.IGetSIDIDDAO;
import com.att.ubm.dao.IMyTaskDAO;
import com.att.ubm.model.ConfigKCPNVPModel;
import com.att.ubm.model.EmployeeDetailsModel;
import com.att.ubm.model.MyTasksModel;
import com.att.ubm.util.DecoratorDate;
import com.att.ubm.util.LabelCacheUtil;


@Repository
public class GetGroupsDetailsDAOImpl implements IGetGroupsDetailsDAO {
	
	@Autowired
	@Qualifier("ubmJdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	

	public JdbcTemplate getMyTaskJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setMyTaskJdbcTemplate(JdbcTemplate myTaskJdbcTemplate) {
		this.jdbcTemplate = myTaskJdbcTemplate;
	}
	
	@Autowired
	@Qualifier("camundaJdbcTemplate")
	private JdbcTemplate ubmJdbcTemplate;
	
	


	public JdbcTemplate getUbmJdbcTemplate() {
		return ubmJdbcTemplate;
	}


	public void setUbmJdbcTemplate(JdbcTemplate ubmJdbcTemplate) {
		this.ubmJdbcTemplate = ubmJdbcTemplate;
	}



	@Override
	public Map<String, List<EmployeeDetailsModel>> getAllGroups() {
		/*String sql = "SELECT uu.user_name as username, ua1.attr_value AS firstname, ua2.attr_value AS lastname, group_name" + 
				"  FROM UMGROUP ug, GROUPUSERROLE gur, UMUSER uu, USERATTR ua1, USERATTR ua2" + 
				"  WHERE uu.user_id = ua1.user_id AND uu.user_id = ua2.user_id" + 
				"  AND ua1.attr_name = 'firstname' AND ua2.attr_name = 'lastname'" + 
				"  AND ug.GROUP_ID = gur.GROUP_ID" + 
				"  AND gur.user_id = uu.user_id " + 
				"  AND (gur.is_group IS NULL OR gur.is_group = 0) AND uu.organization_name = 'default' order by group_name";*/
		String sql="select usr.id_ as username,NAME_ as group_name,first_ as firstname,last_ as lastname from   ACT_ID_USER usr , ACT_ID_GROUP grp  where grp.REV_=usr.rev_";
		Map<String, List<EmployeeDetailsModel>> groupDetails = new LinkedHashMap<String, List<EmployeeDetailsModel>>();
		try {
			System.out.println("Enter into getAllGroups");
			
			SqlRowSet sqlRowSet = ubmJdbcTemplate.queryForRowSet(sql);
			String key="";
			while (sqlRowSet.next()) {
			
				key=LabelCacheUtil.isNull(sqlRowSet.getString("group_name"));
				if(groupDetails.containsKey(key))
				{
					List<EmployeeDetailsModel> tempList=groupDetails.get(key);
					EmployeeDetailsModel obj=new EmployeeDetailsModel();
					obj.setFirstName(sqlRowSet.getString("firstname"));
					obj.setLastName(sqlRowSet.getString("lastname"));
					obj.setAttuid(sqlRowSet.getString("username"));
					tempList.add(obj);
					groupDetails.put(key, tempList);
				}
				else
				{
					List<EmployeeDetailsModel> lstValue=new ArrayList<EmployeeDetailsModel>();
					EmployeeDetailsModel obj=new EmployeeDetailsModel();
					obj.setFirstName(sqlRowSet.getString("firstname"));
					obj.setLastName(sqlRowSet.getString("lastname"));
					obj.setAttuid(sqlRowSet.getString("username"));
					lstValue.add(obj);
					groupDetails.put(key, lstValue);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return groupDetails;
	}


	@Override
	public Map<String, String> getToolTips(String screenName) {
		String sql = "SELECT UBM_KEY, TOOL_TIP FROM UBM_TOOL_TIP WHERE SCREEN_NAME = ?";
		Map<String, String> toolTips = new HashMap<String, String>();
		try {
			System.out.println("Enter into getToolTips");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql,screenName);
			String key="";
			while (sqlRowSet.next()) {
			
				toolTips.put(sqlRowSet.getString("UBM_KEY"), LabelCacheUtil.getToolTipValue(sqlRowSet.getString("TOOL_TIP")));
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return toolTips;
	}

	@Override
	public List<ConfigKCPNVPModel> getConfigKCPNVPDetalls() {
		/*String sql = "select page.sid_type, PAGE.PAGE_NAME , kcp.key, nvp.name, nvp.value, nvp.start_display ,nvp.end_display, kcp.hide_show_la_flag from ubm.config_nvp nvp ,ubm.config_kcp kcp,ubm.config_page page\r\n" + 
				"where PAGE.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and NVP.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID order by kcp.key,NVP.UI_SEQ";*/
		String sql="select stypes.SID_TYPE_NAME as SID_TYPE_NAME, spages.sid_PAGE_name as sid_PAGE_name , kcp.key, nvp.name, nvp.value, nvp.start_display ,nvp.end_display, kcp.hide_show_la_flag from ubm.config_nvp nvp ,ubm.config_kcp kcp,ubm.config_page page,ubm_sid_types stypes,ubm_sid_pages spages " + 
				" where PAGE.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and NVP.CONFIG_KCP_ID = KCP.CONFIG_KCP_ID and STYPES.SID_TYPE_ID=PAGE.SID_TYPE_ID and PAGE.PAGE_ID=SPAGES.SID_PAGE_ID  order by kcp.key,NVP.UI_SEQ";
		List<ConfigKCPNVPModel> configKCPNVPModels=new ArrayList<ConfigKCPNVPModel>();
		try {
			System.out.println("Enter into getConfigKCPNVPDetalls");
			
			SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql);
			
			ConfigKCPNVPModel model=null;
			while (sqlRowSet.next()) {
				model=new ConfigKCPNVPModel();
				model.setSidType(LabelCacheUtil.isNull(sqlRowSet.getString("SID_TYPE_NAME")));
				model.setPageName(LabelCacheUtil.isNull(sqlRowSet.getString("sid_PAGE_name")));
				model.setKey(LabelCacheUtil.isNull(sqlRowSet.getString("KEY")));
				model.setName(LabelCacheUtil.isNull(sqlRowSet.getString("NAME")));
				model.setValue(LabelCacheUtil.isNull(sqlRowSet.getString("VALUE")));
				model.setStartDisplay(sqlRowSet.getLong("START_DISPLAY"));
				model.setEndDisplay(sqlRowSet.getLong("END_DISPLAY"));
				model.setLoadAuotmationFlag(sqlRowSet.getBoolean("HIDE_SHOW_LA_FLAG"));
				configKCPNVPModels.add(model);
				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return configKCPNVPModels;
	}
	

}
