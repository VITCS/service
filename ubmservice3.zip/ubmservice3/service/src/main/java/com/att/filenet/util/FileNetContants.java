package com.att.filenet.util;

public class FileNetContants {
	/*public static final String CE_URL = "http://p8cesiiprodbulkload.web.att.com/wsi/FNCEWS40MTOM";
	public static final String CE_OS_NAME = "TSS";
	public static final String USERNAME = "m93911";
	public static final String PASSWORD = "ETMScheduler@2";
	
	public static final String PATH_USER_FOLDER = "/UBMTest/";*/
}
